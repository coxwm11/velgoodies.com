<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html lang="en-US"  class="supernova"><head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="alternate" type="application/json+oembed" href="https://www.jotform.com/oembed/?format=json&amp;url=https%3A%2F%2Fform.jotform.com%2F221535328519053" title="oEmbed Form">
<link rel="alternate" type="text/xml+oembed" href="https://www.jotform.com/oembed/?format=xml&amp;url=https%3A%2F%2Fform.jotform.com%2F221535328519053" title="oEmbed Form">
<meta property="og:title" content="Digital Device Ambassador Dashboard" >
<meta property="og:url" content="https://form.jotform.com/221535328519053" >
<meta property="og:description" content="Please click the link to complete this form." >
<meta name="slack-app-id" content="AHNMASS8M">
<link rel="shortcut icon" href="https://cdn.jotfor.ms/assets/img/favicons/favicon-2021.svg">
<link rel="canonical" href="https://form.jotform.com/221535328519053" />
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=2.0, user-scalable=1" />
<meta name="HandheldFriendly" content="true" />
<title>Digital Device Ambassador Dashboard</title>
<style type="text/css">@media print{.form-section{display:inline!important}.form-pagebreak{display:none!important}.form-section-closed{height:auto!important}.page-section{position:initial!important}}</style>
<link type="text/css" rel="stylesheet" href="https://cdn01.jotfor.ms/themes/CSS/5e6b428acc8c4e222d1beb91.css?themeRevisionID=5f7ed99c2c2c7240ba580251"/>
<link type="text/css" rel="stylesheet" href="https://cdn02.jotfor.ms/css/styles/payment/payment_styles.css?3.3.33802" />
<link type="text/css" rel="stylesheet" href="https://cdn03.jotfor.ms/css/styles/payment/payment_feature.css?3.3.33802" />
<style type="text/css" id="form-designer-style">
    /* Injected CSS Code */

*,
*:after,
*:before {
  box-sizing: border-box;
}
.form-all {
  font-family: "Inter", sans-serif;
}
.main .jotform-form {
  width: 100%;
  padding: 0 3%;
}
.form-all {
  display: flex;
  flex-direction: column;
  width: 100%;
  max-width: 752px;
}
.form-line-active {
  background-color: #ffffe0;
}
.form-all {
  font-size: 16px;
}
li.form-line {
  margin-top: 12px;
  margin-bottom: 12px;
}
.form-line {
  padding: 12px 10px;
}
.form-section {
  padding: 0px 38px;
}
.form-textbox,
.form-textarea,
.form-radio-other-input,
.form-checkbox-other-input,
.form-captcha input,
.form-spinner input {
  background-color: #ffffff;
}
.form-label {
  font-family: "Inter", sans-serif;
}
.form-line-column {
  width: calc(50% - 8px);
}
.form-checkbox-item label,
.form-checkbox-item span,
.form-radio-item label,
.form-radio-item span {
  color: #404a64;
}
.form-radio-item,
.form-checkbox-item {
  padding-bottom: 0px !important;
}
.form-radio-item:last-child,
.form-checkbox-item:last-child {
  padding-bottom: 0;
}
.form-single-column .form-checkbox-item,
.form-single-column .form-radio-item {
  width: 100%;
}
.form-checkbox-item .editor-container div,
.form-radio-item .editor-container div {
  position: relative;
}
.form-checkbox-item .editor-container div:before,
.form-radio-item .editor-container div:before {
  display: inline-block;
  vertical-align: middle;
  left: 0;
  width: 20px;
  height: 20px;
}
.submit-button {
  font-size: 16px;
  font-weight: normal;
  font-family: "Inter", sans-serif;
}
.submit-button {
  min-width: 180px;
}
.form-all .form-pagebreak-back,
.form-all .form-pagebreak-next {
  font-family: "Inter", sans-serif;
  font-size: 16px;
  font-weight: normal;
}
.form-all .form-pagebreak-back,
.form-all .form-pagebreak-next {
  min-width: 128px;
}
li[data-type="control_image"] div {
  text-align: left;
}
li[data-type="control_image"] img {
  border: none;
  border-width: 0px !important;
  border-style: solid !important;
  border-color: false !important;
}
.supernova {
  height: 100%;
  background-repeat: no-repeat;
  background-attachment: scroll;
  background-position: center top;
  background-size: cover;
}
.supernova {
  background-image: none;
  background-image: url("https://www.jotform.com/uploads/coxwm11/form_files/AdobeStock_419424295.629a538edc9bf2.20826891.jpeg");
}
#stage {
  background-image: none;
  background-image: url("https://www.jotform.com/uploads/coxwm11/form_files/AdobeStock_419424295.629a538edc9bf2.20826891.jpeg");
}
/* | */
.form-all {
  background-repeat: no-repeat;
  background-attachment: scroll;
  background-position: center top;
  background-repeat: repeat;
}
.form-header-group {
  background-repeat: no-repeat;
  background-attachment: scroll;
  background-position: center top;
}
.header-large h1.form-header {
  font-size: 2em;
}
.header-large h2.form-header {
  font-size: 1.5em;
}
.header-large h3.form-header {
  font-size: 1.17em;
}
.header-large h1 + .form-subHeader {
  font-size: 1em;
}
.header-large h2 + .form-subHeader {
  font-size: .875em;
}
.header-large h3 + .form-subHeader {
  font-size: .75em;
}
.header-default h1.form-header {
  font-size: 2em;
}
.header-default h2.form-header {
  font-size: 1.5em;
}
.header-default h3.form-header {
  font-size: 1.17em;
}
.header-default h1 + .form-subHeader {
  font-size: 1em;
}
.header-default h2 + .form-subHeader {
  font-size: .875em;
}
.header-default h3 + .form-subHeader {
  font-size: .75em;
}
.header-small h1.form-header {
  font-size: 2em;
}
.header-small h2.form-header {
  font-size: 1.5em;
}
.header-small h3.form-header {
  font-size: 1.17em;
}
.header-small h1 + .form-subHeader {
  font-size: 1em;
}
.header-small h2 + .form-subHeader {
  font-size: .875em;
}
.header-small h3 + .form-subHeader {
  font-size: .75em;
}
.form-header-group {
  text-align: left;
}
.form-header-group {
  font-family: "Inter", sans-serif;
}
div.form-header-group.header-large {
  margin: 0px -38px;
}
div.form-header-group.header-large {
  padding: 40px 52px;
}
.form-header-group .form-header,
.form-header-group .form-subHeader {
  color: 0;
}
.form-all {
  position: relative;
}
.form-all:before {
  content: "";
  background-image: url("https://www.jotform.com/uploads/coxwm11/form_files/MSCS-Logo-Color-Transparent-Bkg.626165916199c7.52685291.png");
  display: inline-block;
  height: 140px;
  position: absolute;
  background-size: 166px 140px;
  background-repeat: no-repeat;
  width: 100%;
}
.form-all {
  margin-top: 160px !important;
}
.form-all:before {
  top: -150px;
  background-position: top center;
}
.form-line-error {
  overflow: hidden;
  -webkit-transition-property: none;
  -moz-transition-property: none;
  -ms-transition-property: none;
  -o-transition-property: none;
  transition-property: none;
  -webkit-transition-duration: 0.3s;
  -moz-transition-duration: 0.3s;
  -ms-transition-duration: 0.3s;
  -o-transition-duration: 0.3s;
  transition-duration: 0.3s;
  -webkit-transition-timing-function: ease;
  -moz-transition-timing-function: ease;
  -ms-transition-timing-function: ease;
  -o-transition-timing-function: ease;
  transition-timing-function: ease;
  background-color: #fff4f4;
}
.form-line-error .form-error-message {
  background-color: #f23a3c;
  clear: both;
  float: none;
}
.form-line-error .form-error-message .form-error-arrow {
  border-bottom-color: #f23a3c;
}
.form-line-error input:not(#coupon-input),
.form-line-error textarea,
.form-line-error .form-validation-error {
  border: 1px solid #f23a3c;
  box-shadow: 0 0 3px #f23a3c;
}
.supernova {
  background-color: #ffffff;
  background-color: #ecedf3;
}
.supernova body {
  background-color: transparent;
}
.supernova .form-all,
.form-all {
  background-color: #ffffff;
}
.form-textbox,
.form-textarea,
.form-radio-other-input,
.form-checkbox-other-input,
.form-captcha input,
.form-spinner input {
  background-color: #ffffff;
}
.form-matrix-table tr {
  border-color: #e6e6e6;
}
.form-matrix-table tr:nth-child(2n) {
  background-color: #f2f2f2;
}
.form-all {
  color: #2c3345;
}
.form-label-top,
.form-label-left,
.form-label-right,
.form-html {
  color: #2c3345;
}
.form-line-error {
  overflow: hidden;
  -webkit-transition-property: none;
  -moz-transition-property: none;
  -ms-transition-property: none;
  -o-transition-property: none;
  transition-property: none;
  -webkit-transition-duration: 0.3s;
  -moz-transition-duration: 0.3s;
  -ms-transition-duration: 0.3s;
  -o-transition-duration: 0.3s;
  transition-duration: 0.3s;
  -webkit-transition-timing-function: ease;
  -moz-transition-timing-function: ease;
  -ms-transition-timing-function: ease;
  -o-transition-timing-function: ease;
  transition-timing-function: ease;
  background-color: #fff4f4;
}
.form-header-group .form-header,
.form-header-group .form-subHeader {
  color: 0;
}

/*PREFERENCES STYLE*/
    .form-all {
      font-family: Inter, sans-serif;
    }
    .form-all .qq-upload-button,
    .form-all .form-submit-button,
    .form-all .form-submit-reset,
    .form-all .form-submit-print {
      font-family: Inter, sans-serif;
    }
    .form-all .form-pagebreak-back-container,
    .form-all .form-pagebreak-next-container {
      font-family: Inter, sans-serif;
    }
    .form-header-group {
      font-family: Inter, sans-serif;
    }
    .form-label {
      font-family: Inter, sans-serif;
    }
  
    .form-label.form-label-auto {
      
    display: block;
    float: none;
    text-align: left;
    width: 100%;
  
    }
  
    .form-line {
      margin-top: 12px;
      margin-bottom: 12px;
    }
  
    .form-all {
      max-width: 1500px;
      width: 100%;
    }
  
    .form-label.form-label-left,
    .form-label.form-label-right,
    .form-label.form-label-left.form-label-auto,
    .form-label.form-label-right.form-label-auto {
      width: 230px;
    }
  
    .form-all {
      font-size: 16px
    }
    .form-all .qq-upload-button,
    .form-all .qq-upload-button,
    .form-all .form-submit-button,
    .form-all .form-submit-reset,
    .form-all .form-submit-print {
      font-size: 16px
    }
    .form-all .form-pagebreak-back-container,
    .form-all .form-pagebreak-next-container {
      font-size: 16px
    }
  
    .supernova .form-all, .form-all {
      background-color: #fff;
    }
  
    .form-all {
      color: #2C3345;
    }
    .form-header-group .form-header {
      color: #2C3345;
    }
    .form-header-group .form-subHeader {
      color: #2C3345;
    }
    .form-label-top,
    .form-label-left,
    .form-label-right,
    .form-html,
    .form-checkbox-item label,
    .form-radio-item label {
      color: #2C3345;
    }
    .form-sub-label {
      color: #464d5f;
    }
  
    .supernova {
      background-color: #ecedf3;
    }
    .supernova body {
      background: transparent;
    }
  
    .form-textbox,
    .form-textarea,
    .form-dropdown,
    .form-radio-other-input,
    .form-checkbox-other-input,
    .form-captcha input,
    .form-spinner input {
      background-color: #fff;
    }
  
      .supernova {
        height: 100%;
        background-repeat: repeat;
        background-attachment: scroll;
        background-position: center top;
      }
      .supernova {
        background-image: url("https://www.jotform.com/uploads/coxwm11/form_files/AdobeStock_419424295.629a538edc9bf2.20826891.jpeg");
      }
      #stage {
        background-image: url("https://www.jotform.com/uploads/coxwm11/form_files/AdobeStock_419424295.629a538edc9bf2.20826891.jpeg");
      }
    
    .form-all {
      background-image: none;
    }
  
    .form-all {
      position: relative;
    }
    .form-all:before {
      content: "";
      background-image: url("https://www.jotform.com/uploads/coxwm11/form_files/MSCS-Logo-Reverse-White-Transparent-Bkg.629a5434ad61e5.37188021.png");
      display: inline-block;
      height: 144.24242424242425px;
      position: absolute;
      background-size: 170px 144px;
      background-repeat: no-repeat;
      width: 100%;
    }
    .form-all {
      margin-top: 164px !important;
    }
    .form-all:before {
      top: -154px;
      background-position: top center;
      left: 0;
    }
           
  .ie-8 .form-all:before { display: none; }
  .ie-8 {
    margin-top: auto;
    margin-top: initial;
  }
  
  /*PREFERENCES STYLE*//*__INSPECT_SEPERATOR__*/

    /* Injected CSS Code */
</style>

<script src="https://cdn01.jotfor.ms/static/prototype.forms.js" type="text/javascript"></script>
<script src="https://cdn02.jotfor.ms/static/jotform.forms.js?3.3.33802" type="text/javascript"></script>
<script type="text/javascript">	JotForm.newDefaultTheme = true;
	JotForm.extendsNewTheme = false;
	JotForm.newPaymentUIForNewCreatedForms = true;
	JotForm.newPaymentUI = true;

   JotForm.setConditions([{"action":[{"id":"action_1654282035954","skipTo":"page-3: Last Page","isError":false}],"id":"1654282049437","index":"0","link":"Any","priority":"0","terms":[{"id":"term_1654282035954","field":"3","operator":"equals","value":"Student PowerSchool ID","isError":false}],"type":"page"},{"action":[{"id":"action_0_1654282028978","skipTo":"page-2","isError":false}],"id":"1654282008484","index":"1","link":"Any","priority":"1","terms":[{"id":"term_0_1654282028978","field":"3","operator":"equals","value":"School","isError":false}],"type":"page"}]);	JotForm.clearFieldOnHide="disable";
	JotForm.submitError="jumpToFirstError";

	JotForm.init(function(){
	/*INIT-START*/
if (window.JotForm && JotForm.accessible) $('input_5').setAttribute('tabindex',0);
      JotForm.alterTexts(undefined);
	/*INIT-END*/
	});

   JotForm.prepareCalculationsOnTheFly([null,{"name":"heading","qid":"1","text":"Digital Device Ambassador Dashboard","type":"control_head"},{"name":"submit2","qid":"2","text":"Search by PSID","type":"control_button"},{"description":"","name":"typeA","qid":"3","text":"Search Database by:","type":"control_radio"},{"description":"","name":"selectYour","qid":"4","subLabel":"","text":"Select Your School","type":"control_dropdown"},{"description":"","name":"enterStudents","qid":"5","subLabel":"","text":"Enter Student's PSID","type":"control_textbox"},{"name":"searchBy","qid":"6","text":"Search by School","type":"control_button"},{"name":"pageBreak","qid":"7","text":"Page Break","type":"control_pagebreak"},{"name":"pageBreak8","qid":"8","text":"Page Break","type":"control_pagebreak"},{"name":"schoolSearch","qid":"9","text":"School Search","type":"control_head"},{"name":"powerschoolId","qid":"10","text":"PowerSchool ID Search","type":"control_head"},{"description":"","name":"filterBy","qid":"11","subLabel":"","text":"Filter by Grade","type":"control_dropdown"},{"name":"tableFilter","qid":"12","text":"Table Filter","type":"control_head"}]);
   setTimeout(function() {
JotForm.paymentExtrasOnTheFly([null,{"name":"heading","qid":"1","text":"Digital Device Ambassador Dashboard","type":"control_head"},{"name":"submit2","qid":"2","text":"Search by PSID","type":"control_button"},{"description":"","name":"typeA","qid":"3","text":"Search Database by:","type":"control_radio"},{"description":"","name":"selectYour","qid":"4","subLabel":"","text":"Select Your School","type":"control_dropdown"},{"description":"","name":"enterStudents","qid":"5","subLabel":"","text":"Enter Student's PSID","type":"control_textbox"},{"name":"searchBy","qid":"6","text":"Search by School","type":"control_button"},{"name":"pageBreak","qid":"7","text":"Page Break","type":"control_pagebreak"},{"name":"pageBreak8","qid":"8","text":"Page Break","type":"control_pagebreak"},{"name":"schoolSearch","qid":"9","text":"School Search","type":"control_head"},{"name":"powerschoolId","qid":"10","text":"PowerSchool ID Search","type":"control_head"},{"description":"","name":"filterBy","qid":"11","subLabel":"","text":"Filter by Grade","type":"control_dropdown"},{"name":"tableFilter","qid":"12","text":"Table Filter","type":"control_head"}]);}, 20); 
</script>



<style type="text/css">
.tg  {border-collapse:collapse;border-spacing:0;margin:0px auto;}
.tg td{border-color:black;border-style:solid;border-width:1px;font-family:Arial, sans-serif;font-size:14px;
  overflow:hidden;padding:10px 5px;word-break:normal;}
.tg th{border-color:black;border-style:solid;border-width:1px;font-family:Arial, sans-serif;font-size:14px;
  font-weight:normal;overflow:hidden;padding:10px 5px;word-break:normal;}
.tg .tg-j1i3{border-color:inherit;position:-webkit-sticky;position:sticky;text-align:left;top:-1px;vertical-align:top;
  will-change:transform}
.tg .tg-0pky{border-color:inherit;text-align:left;vertical-align:top}
.tg-sort-header::-moz-selection{background:0 0}
.tg-sort-header::selection{background:0 0}.tg-sort-header{cursor:pointer}
.tg-sort-header:after{content:'';float:right;margin-top:7px;border-width:0 5px 5px;border-style:solid;
  border-color:#404040 transparent;visibility:hidden}
.tg-sort-header:hover:after{visibility:visible}
.tg-sort-asc:after,.tg-sort-asc:hover:after,.tg-sort-desc:after{visibility:visible;opacity:.4}
.tg-sort-desc:after{border-bottom:none;border-width:5px 5px 0}@media screen and (max-width: 767px) {.tg {width: auto !important;}.tg col {width: auto !important;}.tg-wrap {overflow-x: auto;-webkit-overflow-scrolling: touch;margin: auto 0px;}}</style>

<script charset="utf-8">var TGSort=window.TGSort||function(n){"use strict";function r(n){return n?n.length:0}function t(n,t,e,o=0){for(e=r(n);o<e;++o)t(n[o],o)}function e(n){return n.split("").reverse().join("")}function o(n){var e=n[0];return t(n,function(n){for(;!n.startsWith(e);)e=e.substring(0,r(e)-1)}),r(e)}function u(n,r,e=[]){return t(n,function(n){r(n)&&e.push(n)}),e}var a=parseFloat;function i(n,r){return function(t){var e="";return t.replace(n,function(n,t,o){return e=t.replace(r,"")+"."+(o||"").substring(1)}),a(e)}}var s=i(/^(?:\s*)([+-]?(?:\d+)(?:,\d{3})*)(\.\d*)?$/g,/,/g),c=i(/^(?:\s*)([+-]?(?:\d+)(?:\.\d{3})*)(,\d*)?$/g,/\./g);function f(n){var t=a(n);return!isNaN(t)&&r(""+t)+1>=r(n)?t:NaN}function d(n){var e=[],o=n;return t([f,s,c],function(u){var a=[],i=[];t(n,function(n,r){r=u(n),a.push(r),r||i.push(n)}),r(i)<r(o)&&(o=i,e=a)}),r(u(o,function(n){return n==o[0]}))==r(o)?e:[]}function v(n){if("TABLE"==n.nodeName){for(var a=function(r){var e,o,u=[],a=[];return function n(r,e){e(r),t(r.childNodes,function(r){n(r,e)})}(n,function(n){"TR"==(o=n.nodeName)?(e=[],u.push(e),a.push(n)):"TD"!=o&&"TH"!=o||e.push(n)}),[u,a]}(),i=a[0],s=a[1],c=r(i),f=c>1&&r(i[0])<r(i[1])?1:0,v=f+1,p=i[f],h=r(p),l=[],g=[],N=[],m=v;m<c;++m){for(var T=0;T<h;++T){r(g)<h&&g.push([]);var C=i[m][T],L=C.textContent||C.innerText||"";g[T].push(L.trim())}N.push(m-v)}t(p,function(n,t){l[t]=0;var a=n.classList;a.add("tg-sort-header"),n.addEventListener("click",function(){var n=l[t];!function(){for(var n=0;n<h;++n){var r=p[n].classList;r.remove("tg-sort-asc"),r.remove("tg-sort-desc"),l[n]=0}}(),(n=1==n?-1:+!n)&&a.add(n>0?"tg-sort-asc":"tg-sort-desc"),l[t]=n;var i,f=g[t],m=function(r,t){return n*f[r].localeCompare(f[t])||n*(r-t)},T=function(n){var t=d(n);if(!r(t)){var u=o(n),a=o(n.map(e));t=d(n.map(function(n){return n.substring(u,r(n)-a)}))}return t}(f);(r(T)||r(T=r(u(i=f.map(Date.parse),isNaN))?[]:i))&&(m=function(r,t){var e=T[r],o=T[t],u=isNaN(e),a=isNaN(o);return u&&a?0:u?-n:a?n:e>o?n:e<o?-n:n*(r-t)});var C,L=N.slice();L.sort(m);for(var E=v;E<c;++E)(C=s[E].parentNode).removeChild(s[E]);for(E=v;E<c;++E)C.appendChild(s[v+L[E-v]])})})}}n.addEventListener("DOMContentLoaded",function(){for(var t=n.getElementsByClassName("tg"),e=0;e<r(t);++e)try{v(t[e])}catch(n){}})}(document)</script>

<!--Beginning of my code-->



<style> 



/*Search Elements */
.searchTable{
  display: block;
  overflow: scroll;
  height: 500px;
  overflow-y: scroll;
    
}
.searchTable, .searchHeading{
    border: 1px solid #333;
    
    border-collapse: collapse;
    
    
}

.searchData{
    border: 1px solid #333;
    
    border-collapse: collapse;
}
th {
  background: white;
  position: sticky;
  top: 0;
}



/*Navigation Bar*/


.topnav {
  overflow: hidden;
  background-color: #333;
}

.topnav a {
  float: left;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

.topnav a:hover {
  background-color: #ddd;
  color: black;
}

.topnav a.active {
  background-color: blue;
  color: white;
}


/*End of Navigation Bar */

</style>


    <script>
function searchBar() {
  var input, filter, table, tr, td, i, txtValue;
  input = document.getElementById("myInput");
  filter = input.value.toUpperCase();
  table = document.getElementById("myTable");
  tr = table.getElementsByTagName("tr");
  for (i = 0; i < tr.length; i++) {
    td = tr[i].getElementsByTagName("td")[7];
    if (td) {
      txtValue = td.textContent || td.innerText;
      if (txtValue.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    }       
  }
}






</script>

    <script>
function searchBar1() {
  var input, filter, table, tr, td, i, txtValue;
  input = document.getElementById("myInput1");
  filter = input.value.toUpperCase();
  table = document.getElementById("myTable1");
  tr = table.getElementsByTagName("tr");
  for (i = 0; i < tr.length; i++) {
    td = tr[i].getElementsByTagName("td")[7];
    if (td) {
      txtValue = td.textContent || td.innerText;
      if (txtValue.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    }       
  }
}






</script>


<script>
    
    function selectFilter1() {
  var input, filter, table, tr, td, i;
  input = document.getElementById("myList1");
  filter = input.value.toUpperCase();
  table = document.getElementById("myTable");
  tr = table.getElementsByTagName("tr");
  for (i = 0; i < tr.length; i++) {
    td = tr[i].getElementsByTagName("td")[5];
    if (td) {
      if (td.innerHTML.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    }       
  }
}
</script>


<script>
    
    function selectFilter() {
  var input, filter, table, tr, td, i;
  input = document.getElementById("myList2");
  filter = input.value.toUpperCase();
  table = document.getElementById("myTable");
  tr = table.getElementsByTagName("tr");
  for (i = 0; i < tr.length; i++) {
    td = tr[i].getElementsByTagName("td")[4];
    if (td) {
      if (td.innerHTML.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    }       
  }
}
</script>


<style>
.searchBox{
width: 50%;


}

.searchBox1{
width: 70%;


}


#cid_38{
    background-color:#D3D3D3;
    border: solid 1px;
}
</style>
<!--End of my code-->



</head>
<body>
<form class="jotform-form" action="Digital_Device_Ambassador_Dashboard.php" method="post" name="form_221535328519053" id="221535328519053" accept-charset="utf-8" autocomplete="on">
  <input type="hidden" name="formID" value="221535328519053" />
  <input type="hidden" id="JWTContainer" value="" />
  <input type="hidden" id="cardinalOrderNumber" value="" />
  <div role="main" class="form-all">
    <div class="formLogoWrapper Center">
      <img loading="lazy" class="formLogoImg" src="https://www.jotform.com/uploads/coxwm11/form_files/MSCS-Logo-Reverse-White-Transparent-Bkg.629a5434ad61e5.37188021.png" height="144" width="170">
    </div>
    <style>
      .formLogoWrapper { display:inline-block; position: absolute; width: 100%;} .form-all:before { background: none !important;} .formLogoWrapper.Center { top: -154px; text-align: center;}
    </style>
    
       <div class="topnav">
  <a  href="http://www.velgoodies.com/Student%20Device%20Request%20Files/Form.php">Home</a>
  <a class="active" href="http://velgoodies.com/Student%20Device%20Request%20Files/Digital_Device_Ambassador_Dashboard.php" >DD Ambassador Dashboard</a>
  <a href="https://scstn.powerschool.com/admin" target = "_blank">PowerSchool</a>
  <a href="https://student1-1devicetheftloss.scsk12.org/" target = "_blank">Theft, Damage and Vandalism</a>
</div>
    <ul class="form-section page-section">
      <li id="cid_1" class="form-input-wide" data-type="control_head">
        <div style="display:table;width:100%">
          <div class="form-header-group hasImage header-large" data-imagealign="Left">
            <div class="header-logo">
              <img src="https://www.jotform.com/uploads/coxwm11/form_files/vetting.629a55841f9057.45419872.jpg" alt="" width="100" class="header-logo-left" />
            </div>
            <div class="header-text httal htvam">
              <h1 id="header_1" class="form-header" data-component="header">
                Digital Device Ambassador Dashboard
              </h1>
            </div>
          </div>
        </div>
      </li>
      <li class="form-line jf-required" data-type="control_radio" id="id_3">
        <label class="form-label form-label-top form-label-auto" id="label_3" for="input_3">
          Search Database by:
          <span class="form-required">
            *
          </span>
        </label>
        <div id="cid_3" class="form-input-wide jf-required" data-layout="full">
          <div class="form-single-column" role="group" aria-labelledby="label_3" data-component="radio">
            <span class="form-radio-item" style="clear:left">
              <span class="dragger-item">
              </span>
              <input type="radio" aria-describedby="label_3" class="form-radio validate[required]" id="input_3_0" name="q3_typeA" value="School" required="" />
              <label id="label_input_3_0" for="input_3_0"> School </label>
            </span>
            <span class="form-radio-item" style="clear:left">
              <span class="dragger-item">
              </span>
              <input type="radio" aria-describedby="label_3" class="form-radio validate[required]" id="input_3_1" name="q3_typeA" value="Student PowerSchool ID" required="" />
              <label id="label_input_3_1" for="input_3_1"> Student PowerSchool ID </label>
            </span>
          </div>
        </div>
      </li>
      
           <li id="cid_12" class="form-input-wide" data-type="control_head">
        <div class="form-header-group  header-small">
          <div class="header-text httal htvam">
            <h3 style= "color: blue" id="header_12" class="form-header" data-component="header">
              Table Filter
            </h3>
            <div id="subHeader_12" class="form-subHeader">
              Select the grade to filter table results.
            </div>
          </div>
        </div>
      </li>
      <li class="form-line fixed-width form-line-column form-col-1" data-type="control_dropdown" id="id_11">
        <label style = "color: blue" class="form-label form-label-top" id="label_11" for="input_11"> Filter by Grade </label>
        <div id="cid_11" class="form-input-wide" data-layout="half">
          <select  id="myList1" onchange="selectFilter1()" class="form-dropdown" name="q11_filterBy" style="width:310px" data-component="dropdown">
            <option value=""> Please Select </option>
               <option value="0"> KK </option>
            <option value="1"> 1 </option>
            <option value="2"> 2 </option>
            <option value="3"> 3 </option>
            <option value="4"> 4 </option>
            <option value="5"> 5 </option>
            <option value="6"> 6 </option>
            <option value="7"> 7 </option>
            <option value="8"> 8 </option>
            <option value="9"> 9 </option>
            <option value="10"> 10 </option>
            <option value="11"> 11 </option>
            <option value="12"> 12 </option>
          </select>
        </div>
      </li>

      <li id="cid_8" class="form-input-wide" data-type="control_pagebreak">
        <div class="form-pagebreak" data-component="pagebreak">
          <div class="form-pagebreak-back-container">
            <button id="form-pagebreak-back_8" type="button" class="form-pagebreak-back  jf-form-buttons" data-component="pagebreak-back">
              Back
            </button>
          </div>
          <div class="form-pagebreak-next-container">
            <button id="form-pagebreak-next_8" type="button" class="form-pagebreak-next  jf-form-buttons" data-component="pagebreak-next">
              Next
            </button>
          </div>
          <div style="clear:both" class="pageInfo form-sub-label" id="pageInfo_8">
          </div>
        </div>
      </li>
      
             
             <?php



//Database Connection

$db_host = 'localhost:3306';
$db_name = 'coxwm11_SDRForm';
$db_user = 'coxwm11_VEL';
$db_pw = 'Ethel1908!!!';


$conn = new mysqli($db_host, $db_user, $db_pw, $db_name );

//Form Variables
$school_Name = $_POST['q4_selectYour'];
$stuPSID = $_POST['q5_enterStudents'];


if($conn-> connect_error){
    die('Connection Failed : '.$conn -> connect_error);
    
  
}else{
   

   
   if ($_POST['action'] == 'schoolSearch') {
   //action for search here
   
   
   
   
    $result = mysqli_query ($conn, "SELECT * FROM `Student Device Request` WHERE `School` = '$school_Name' ORDER BY `Grade` ASC, `FirstName` ASC, `Date` ASC ");
 
   
         if((mysqli_num_rows($result) > 0)){
        
          
    
        
           echo "<table class ='searchTable' id='tg-fJZ8J' text-align=center>";
           
           
        

echo "<tr>"; 
echo "<th class = 'searchHeading'> Form ID </th>";
echo "<th class = 'searchHeading'> Date </th>";
echo "<th class = 'searchHeading'> Addressed </th>";
echo "<th class = 'searchHeading'> Device Ambassador </th>";
echo "<th class = 'searchHeading'> School </th>";
echo "<th class = 'searchHeading'> Student Grade </th>";
echo "<th class = 'searchHeading'> Student Name</th>";
echo "<th class = 'searchHeading'> PSID </th>";
echo "<th class = 'searchHeading'> Reason for Request </th>";
echo "<th class = 'searchHeading'> Response </th>";
echo "<th class = 'searchHeading'> Reason for Denial </th>";


echo "</tr>";

while($row = $result->fetch_assoc()) {
    
echo "<tr >";
echo "<td class='searchData' >" . $row['formID'] . "</td>";
echo "<td class='searchData' >" . $row['Date'] . "</td>";
echo "<td class='searchData' style=text-align:center; >" . $row['Addressed'] . "</td>";
echo "<td class='searchData' style=text-align:center; >" . $row['DDAName'] . "</td>";
echo "<td class='searchData' >" . $row['School'] . "</td>";
echo "<td class='searchData' style=text-align:center; >" . $row['Grade'] . "</td>";

echo "<td class='searchData' >" . $row['FirstName'] . " " . $row['LastName'] ."</td>";
echo "<td class='searchData' >" . $row['PSID'] . "</td>";
echo "<td class='searchData' >" . $row['Reason'] . "</td>";

if ($row['Response'] == "DENIED"){
          
       echo"<td style= 'background-color:#FF7F7F; color:black; border: solid black 1px'>" . $row['Response']. "</td>";
          
      }
      elseif( !empty($row['Response'])){
           echo"<td style= 'background-color: #90EE90; color:black; border: solid black 1px'>". $row['Response']."</td>";
      }
      else{
          
       echo"<td  style='color:black; border:solid black 1px'>" . $row['Response']. "</td>";
          
      }



echo "<td class='searchData' >" . $row['DenialReason'] . "</td>";


echo "</tr>";

    
}

  echo "</table>";
 

$result-> close();



          
      }//end of if rows>0
      
      else{
          echo "<h3 style='color: red';>Your search returned 0 results.</h3>";
          
      }
   
   
      
       
       
    
    
}

 elseif ($_POST['action'] == 'stuPSIDBtn') {
   //action for search here
   
   
   
   
    $result = mysqli_query ($conn, "SELECT * FROM `Student Device Request` WHERE `PSID` = '$stuPSID' ORDER BY `Date` ASC ");
 
   
         if((mysqli_num_rows($result) > 0)){
        
          
    
        
           echo "<table class ='searchTable' id= 'myTable' text-align=center>";
           
           
        

echo "<tr>"; 
echo "<th class = 'searchHeading'> Form ID </th>";
echo "<th class = 'searchHeading'> Date </th>";
echo "<th class = 'searchHeading'> Addressed </th>";
echo "<th class = 'searchHeading'> Device Ambassador </th>";
echo "<th class = 'searchHeading'> School </th>";
echo "<th class = 'searchHeading'> Student Grade </th>";
echo "<th class = 'searchHeading'> Student Name</th>";
echo "<th class = 'searchHeading'> PSID </th>";
echo "<th class = 'searchHeading'> Reason for Request </th>";
echo "<th class = 'searchHeading'> Response </th>";
echo "<th class = 'searchHeading'> Reason for Denial </th>";


echo "</tr>";

while($row = $result->fetch_assoc()) {
    
echo "<tr >";
echo "<td class='searchData' >" . $row['formID'] . "</td>";
echo "<td class='searchData' >" . $row['Date'] . "</td>";
echo "<td class='searchData' style=text-align:center; >" . $row['Addressed'] . "</td>";
echo "<td class='searchData' style=text-align:center; >" . $row['DDAName'] . "</td>";
echo "<td class='searchData' >" . $row['School'] . "</td>";
echo "<td class='searchData' style=text-align:center; >" . $row['Grade'] . "</td>";

echo "<td class='searchData' >" . $row['FirstName'] . " " . $row['LastName'] ."</td>";
echo "<td class='searchData' >" . $row['PSID'] . "</td>";
echo "<td class='searchData' >" . $row['Reason'] . "</td>";

if ($row['Response'] == "DENIED"){
          
       echo"<td style= 'background-color:#FF7F7F; color:black; border: solid black 1px'>" . $row['Response']. "</td>";
          
      }
      elseif( !empty($row['Response'])){
           echo"<td style= 'background-color: #90EE90; color:black; border: solid black 1px'>". $row['Response']."</td>";
      }
      else{
          
       echo"<td  style='color:black; border:solid black 1px'>" . $row['Response']. "</td>";
          
      }



echo "<td class='searchData' >" . $row['DenialReason'] . "</td>";


echo "</tr>";

    
}

  echo "</table>";
 

$result-> close();



          
      }//end of if rows>0
      
      else{
         
         echo "<h3 style='color: red';>Your search returned 0 results.</h3>";
      }
   
   
      
       
       
    
    
}


}// end of else conn dies

$conn->close();
?> 
    </ul>
    <ul class="form-section page-section" style="display:none;">
      <li id="cid_9" class="form-input-wide" data-type="control_head">
        <div style="display:table;width:100%">
          <div class="form-header-group hasImage header-default" data-imagealign="Left">
            <div class="header-logo">
              <img src="https://www.jotform.com/uploads/coxwm11/form_files/a7d77bc9b4e0ce9520dcd97c71b03dda.629a57e5585480.21671357.png" alt="" width="150" class="header-logo-left" />
            </div>
            <div class="header-text httal htvam">
              <h2 id="header_9" class="form-header" data-component="header">
                School Search
              </h2>
              <div id="subHeader_9" class="form-subHeader">
                Enter your school name to view submissions.
              </div>
            </div>
          </div>
        </div>
      </li>
      <li class="form-line jf-required" data-type="control_dropdown" id="id_4">
        <label class="form-label form-label-top form-label-auto" id="label_4" for="input_4">
          Select Your School
          <span class="form-required">
            *
          </span>
        </label>
        <div id="cid_4" class="form-input-wide jf-required" data-layout="half">
          <select class="form-dropdown validate[required]"  name="q4_selectYour" style="width:310px" data-component="dropdown" required="">
            <option value=""> Please Select </option>
               <option value="A. B. Hill ES "> A. B. Hill ES </option>
            <option value="A. Maceo Walker MS "> A. Maceo Walker MS </option>
            <option value="Adolescent Parenting Program  "> Adolescent Parenting Program </option>
            <option value="Airways Achievement Academy "> Airways Achievement Academy </option>
            <option value="Alcy ES "> Alcy ES </option>
            <option value="Alton ES "> Alton ES </option>
            <option value="American Way MS "> American Way MS </option>
            <option value="Avon Lennox HS "> Avon Lennox HS </option>
            <option value="Balmoral-Ridgeway ES "> Balmoral-Ridgeway ES </option>
            <option value="Barret&#x27;s Chapel K-8 "> Barret&#x27;s Chapel K-8 </option>
            <option value="Belle Forest ES "> Belle Forest ES </option>
            <option value="Bellevue MS "> Bellevue MS </option>
            <option value="Berclair ES "> Berclair ES </option>
            <option value="Bethel Grove ES "> Bethel Grove ES </option>
            <option value="Bolton HS "> Bolton HS </option>
            <option value="Booker T. Washington MS "> Booker T. Washington MS </option>
            <option value="Brewster ES "> Brewster ES </option>
            <option value="Brownsville Road ES "> Brownsville Road ES </option>
            <option value="Bruce ES "> Bruce ES </option>
            <option value="Central HS "> Central HS </option>
            <option value="Cherokee ES "> Cherokee ES </option>
            <option value="Chickasaw MS "> Chickasaw MS </option>
            <option value="Chimneyrock ES "> Chimneyrock ES </option>
            <option value="Colonial MS "> Colonial MS </option>
            <option value="Cordova ES "> Cordova ES </option>
            <option value="Cordova HS "> Cordova HS </option>
            <option value="Cordova MS "> Cordova MS </option>
            <option value="Craigmont HS "> Craigmont HS </option>
            <option value="Craigmont MS "> Craigmont MS </option>
            <option value="Cromwell ES "> Cromwell ES </option>
            <option value="Crump ES "> Crump ES </option>
            <option value="Cummings K-8 "> Cummings K-8 </option>
            <option value="Delano ES "> Delano ES </option>
            <option value="Dexter ES "> Dexter ES </option>
            <option value="Dexter MS "> Dexter MS </option>
            <option value="Double Tree ES "> Double Tree ES </option>
            <option value="Douglass HS "> Douglass HS </option>
            <option value="Douglass K-8 "> Douglass K-8 </option>
            <option value="Downtown ES "> Downtown ES </option>
            <option value="Dunbar ES "> Dunbar ES </option>
            <option value="East High STEM  "> East High STEM </option>
            <option value="EE Jeter K-8 "> EE Jeter K-8 </option>
            <option value="Egypt ES "> Egypt ES </option>
            <option value="Evans ES "> Evans ES </option>
            <option value="Ford Road ES "> Ford Road ES </option>
            <option value="Fox Meadows ES "> Fox Meadows ES </option>
            <option value="G.W. Carver Career Academy "> G.W. Carver Career Academy </option>
            <option value="Gardenview ES "> Gardenview ES </option>
            <option value="Geeter K-8 "> Geeter K-8 </option>
            <option value="Georgian Hills MS "> Georgian Hills MS </option>
            <option value="Germanshire ES "> Germanshire ES </option>
            <option value="Germantown ES "> Germantown ES </option>
            <option value="Germantown HS "> Germantown HS </option>
            <option value="Germantown MS "> Germantown MS </option>
            <option value="Getwell ES "> Getwell ES </option>
            <option value="Gordon Achievement Academy "> Gordon Achievement Academy </option>
            <option value="Grahamwood ES "> Grahamwood ES </option>
            <option value="Grandview Heights MS "> Grandview Heights MS </option>
            <option value="Hamilton HS "> Hamilton HS </option>
            <option value="Hamilton K-8 "> Hamilton K-8 </option>
            <option value="Havenivew MS "> Havenivew MS </option>
            <option value="Hawkins Mill ES "> Hawkins Mill ES </option>
            <option value="Hickory Ridge ES "> Hickory Ridge ES </option>
            <option value="Hickory Ridge MS "> Hickory Ridge MS </option>
            <option value="Highland Oaks ES "> Highland Oaks ES </option>
            <option value="Highland Oaks MS "> Highland Oaks MS </option>
            <option value="Hollis F. Price HS "> Hollis F. Price HS </option>
            <option value="Holmes Road ES "> Holmes Road ES </option>
            <option value="Hope Academy"> Hope Academy </option>
            <option value="Ida B. Wells Academy "> Ida B. Wells Academy </option>
            <option value="Idlewild ES "> Idlewild ES </option>
            <option value="J.P. Freeman K-8 "> J.P. Freeman K-8 </option>
            <option value="Jackson ES "> Jackson ES </option>
            <option value="Kate Bond ES "> Kate Bond ES </option>
            <option value="Kate Bond MS "> Kate Bond MS </option>
            <option value="Keystone ES "> Keystone ES </option>
            <option value="Kingsbury ES "> Kingsbury ES </option>
            <option value="Kingsbury HS "> Kingsbury HS </option>
            <option value="Kingsbury MS "> Kingsbury MS </option>
            <option value="Kirby HS "> Kirby HS </option>
            <option value="LaRose ES "> LaRose ES </option>
            <option value="Levi ES  "> Levi ES </option>
            <option value="Lowrance K-8 "> Lowrance K-8 </option>
            <option value="Lucie E. Campbell ES "> Lucie E. Campbell ES </option>
            <option value="Lucy ES "> Lucy ES </option>
            <option value="Macon Hall ES "> Macon Hall ES </option>
            <option value="Manassas HS "> Manassas HS </option>
            <option value="Maxine Smith MS "> Maxine Smith MS </option>
            <option value="Medical District HS"> Medical District HS </option>
            <option value="Melrose HS "> Melrose HS </option>
            <option value="Memphis Virtual School"> Memphis Virtual School </option>
            <option value="Middle College HS "> Middle College HS </option>
            <option value="Mitchell HS "> Mitchell HS </option>
            <option value="Mt. Pisgah MS "> Mt. Pisgah MS </option>
            <option value="New Comers International Ctr "> New Comers International Ctr </option>
            <option value="Newberry ES "> Newberry ES </option>
            <option value="Northaven ES "> Northaven ES </option>
            <option value="Northeast Prep Academy "> Northeast Prep Academy </option>
            <option value="Northwest Prep Academy  "> Northwest Prep Academy </option>
            <option value="Oak Forest ES "> Oak Forest ES </option>
            <option value="Oakhaven ES "> Oakhaven ES </option>
            <option value="Oakhaven HS "> Oakhaven HS </option>
            <option value="Oakhaven MS "> Oakhaven MS </option>
            <option value="Oakshire ES "> Oakshire ES </option>
            <option value="Overton HS "> Overton HS </option>
            <option value="Parkway Village ES "> Parkway Village ES </option>
            <option value="Peabody ES "> Peabody ES </option>
            <option value="Raleigh Bartlett Meadows ES "> Raleigh Bartlett Meadows ES </option>
            <option value="Raleigh Egypt HS "> Raleigh Egypt HS </option>
            <option value="Raleigh Egypt MS "> Raleigh Egypt MS </option>
            <option value="Richland ES "> Richland ES </option>
            <option value="Ridgeway HS "> Ridgeway HS </option>
            <option value="Ridgeway MS "> Ridgeway MS </option>
            <option value="Riverview K-8 "> Riverview K-8 </option>
            <option value="Riverwood ES "> Riverwood ES </option>
            <option value="Robert R. Church ES "> Robert R. Church ES </option>
            <option value="Ross ES "> Ross ES </option>
            <option value="Rozelle ES "> Rozelle ES </option>
            <option value="Scenic Hills ES "> Scenic Hills ES </option>
            <option value="Sea Isle ES "> Sea Isle ES </option>
            <option value="Shady Grove ES "> Shady Grove ES </option>
            <option value="Sharpe ES "> Sharpe ES </option>
            <option value="Sheffield ES "> Sheffield ES </option>
            <option value="Sheffield HS "> Sheffield HS </option>
            <option value="Shelby Oaks ES "> Shelby Oaks ES </option>
            <option value="Sherwood ES "> Sherwood ES </option>
            <option value="Sherwood MS "> Sherwood MS </option>
            <option value="Shrine School "> Shrine School </option>
            <option value="Snowden K-8 "> Snowden K-8 </option>
            <option value="South Park ES "> South Park ES </option>
            <option value="Southwind ES "> Southwind ES </option>
            <option value="Southwind HS "> Southwind HS </option>
            <option value="Springdale ES "> Springdale ES </option>
            <option value="Treadwell ES "> Treadwell ES </option>
            <option value="Treadwell MS "> Treadwell MS </option>
            <option value="Trezevant HS "> Trezevant HS </option>
            <option value="Vollentine ES "> Vollentine ES </option>
            <option value="Wells Station ES "> Wells Station ES </option>
            <option value="Westhaven ES "> Westhaven ES </option>
            <option value="Westside ES "> Westside ES </option>
            <option value="Westwood HS "> Westwood HS </option>
            <option value="White Station ES "> White Station ES </option>
            <option value="White Station HS "> White Station HS </option>
            <option value="White Station MS "> White Station MS </option>
            <option value="Whitehaven ES "> Whitehaven ES </option>
            <option value="Whitehaven HS "> Whitehaven HS </option>
            <option value="Willow Oaks ES "> Willow Oaks ES </option>
            <option value="Winchester ES "> Winchester ES </option>
            <option value="Winridge ES "> Winridge ES </option>
            <option value="Wooddale HS "> Wooddale HS </option>
            <option value="Woodstock MS "> Woodstock MS </option>
          </select>
        </div>
      </li>
      
      
           <li id="cid_6" class="form-input-wide" data-type="control_button">
        <div data-align="auto" class="form-buttons-wrapper form-buttons-auto  form-pagebreak jsTest-button-wrapperField">
          <div class="form-pagebreak-back-container">
            <button id="form-pagebreak-back_7" type="button" class="form-pagebreak-back  jf-form-buttons" data-component="pagebreak-back">
              Back
            </button>
          </div>
          <button id="input_18" type="submit" name = "action" value = "schoolSearch" class="form-submit-button form-submit-button-simple_black submit-button jf-form-buttons jsTest-submitField" data-component="button" data-content="">
            Search by School
          </button>
          <div class="form-pagebreak-next-container">
            <button id="form-pagebreak-next_7" type="button" class="form-pagebreak-next  button-hidden jf-form-buttons" data-component="pagebreak-next">
              Next
            </button>
          </div>
        </div>
      </li>
      
 
 
    </ul>
    <ul class="form-section page-section" style="display:none;">
      <li id="cid_10" class="form-input-wide" data-type="control_head">
        <div style="display:table;width:100%">
          <div class="form-header-group hasImage header-default" data-imagealign="Left">
            <div class="header-logo">
              <img src="https://www.jotform.com/uploads/coxwm11/form_files/1ea804dbf6a45ba977293c237ecc1b08_XL.629a58402d3339.83389042.jpg" alt="" width="100" class="header-logo-left" />
            </div>
            <div class="header-text httal htvam">
              <h2 id="header_10" class="form-header" data-component="header">
                PowerSchool ID Search
              </h2>
              <div id="subHeader_10" class="form-subHeader">
                Enter student&#x27;s PSID to view submissions.
              </div>
            </div>
          </div>
        </div>
      </li>
      <li class="form-line jf-required" data-type="control_textbox" id="id_5">
        <label class="form-label form-label-top form-label-auto" id="label_5" for="input_5">
          Enter Student's PSID
          <span class="form-required">
            *
          </span>
        </label>
        <div id="cid_5" class="form-input-wide jf-required" data-layout="half">
          <input type="text" id="input_5" name="q5_enterStudents" data-type="input-textbox" class="form-textbox validate[required]" data-defaultvalue="" style="width:310px" size="310" value="" data-component="textbox" aria-labelledby="label_5" required="" />
        </div>
      </li>
      <li class="form-line" data-type="control_button" id="id_2">
        <div id="cid_2" class="form-input-wide" data-layout="full">
          <div data-align="auto" class="form-buttons-wrapper form-buttons-auto   jsTest-button-wrapperField">
            <button id="input_2" name = "action" value = "stuPSIDBtn"  class="form-submit-button form-submit-button-book_blue2 submit-button jf-form-buttons jsTest-submitField" data-component="button" data-content="">
              Search by PSID
            </button>
          </div>
        </div>
      </li>
      <li style="display:none">
        Should be Empty:
        <input type="text" name="website" value="" />
      </li>
    </ul>
  </div>
  <script>
  JotForm.showJotFormPowered = "new_footer";
  </script>
  <script>
  JotForm.poweredByText = "Powered by Jotform";
  </script>
  <input type="hidden" class="simple_spc" id="simple_spc" name="simple_spc" value="221535328519053" />
  <script type="text/javascript">
  var all_spc = document.querySelectorAll("form[id='221535328519053'] .si" + "mple" + "_spc");
for (var i = 0; i < all_spc.length; i++)
{
  all_spc[i].value = "221535328519053-221535328519053";
}
  </script>
  <div class="formFooter-heightMask">
  </div>

</form></body>
</html>
<script type="text/javascript">JotForm.ownerView=true;</script><script src="https://cdn.jotfor.ms//js/vendor/smoothscroll.min.js?v=3.3.33802"></script>
<script src="https://cdn.jotfor.ms//js/errorNavigation.js?v=3.3.33802"></script>
