<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html lang="en-US"  class="supernova"><head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="alternate" type="application/json+oembed" href="https://www.jotform.com/oembed/?format=json&amp;url=https%3A%2F%2Fform.jotform.com%2F221104092209039" title="oEmbed Form">
<link rel="alternate" type="text/xml+oembed" href="https://www.jotform.com/oembed/?format=xml&amp;url=https%3A%2F%2Fform.jotform.com%2F221104092209039" title="oEmbed Form">
<meta property="og:title" content="Form" >
<meta property="og:url" content="https://form.jotform.com/221104092209039" >
<meta property="og:description" content="Please click the link to complete this form." >
<meta name="slack-app-id" content="AHNMASS8M">
<link rel="shortcut icon" href="https://cdn.jotfor.ms/assets/img/favicons/favicon-2021.svg">
<link rel="canonical" href="https://form.jotform.com/221104092209039" />
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=2.0, user-scalable=1" />
<meta name="HandheldFriendly" content="true" />
<title>Student Device Request Form</title>
<style type="text/css">@media print{.form-section{display:inline!important}.form-pagebreak{display:none!important}.form-section-closed{height:auto!important}.page-section{position:initial!important}}</style>
<link type="text/css" rel="stylesheet" href="https://cdn01.jotfor.ms/themes/CSS/5e6b428acc8c4e222d1beb91.css?themeRevisionID=5f7ed99c2c2c7240ba580251"/>
<link type="text/css" rel="stylesheet" href="https://cdn02.jotfor.ms/css/styles/payment/payment_styles.css?3.3.32842" />
<link type="text/css" rel="stylesheet" href="https://cdn03.jotfor.ms/css/styles/payment/payment_feature.css?3.3.32842" />
<script src="https://cdn.jotfor.ms//js/errorNavigation.js?v=3.3.32842"></script>
<script>
    
    // This calculates the date

function autoDate () {
	var tDay = new Date();
	var tMonth = tDay.getMonth()+1;
	var tDate = tDay.getDate();
	if ( tMonth < 10) tMonth = "0"+tMonth;
	if ( tDate < 10) tDate = "0"+tDate;
	document.getElementById("tDate").value = tMonth+"/"+tDate+"/"+tDay.getFullYear();
 }


// This loads the date automattically in the date field and loads the form id in the addLoadEvent

function addLoadEvent(func) {
  var oldonload = window.onload;
  if (typeof window.onload != 'function') {
    window.onload = func;
  } else {
    window.onload = function() {
        
      if (oldonload) {
        oldonload();
      }
      func();
    }
  }
}

addLoadEvent(function() {
  autoDate();
  
}); 
</script>




<style type="text/css" id="form-designer-style">
    /* Injected CSS Code */
/*PREFERENCES STYLE*/
    .form-all {
      font-family: Inter, sans-serif;
    }
    .form-all .qq-upload-button,
    .form-all .form-submit-button,
    .form-all .form-submit-reset,
    .form-all .form-submit-print {
      font-family: Inter, sans-serif;
    }
    .form-all .form-pagebreak-back-container,
    .form-all .form-pagebreak-next-container {
      font-family: Inter, sans-serif;
    }
    .form-header-group {
      font-family: Inter, sans-serif;
    }
    .form-label {
      font-family: Inter, sans-serif;
    }
  
    .form-label.form-label-auto {
      
    display: block;
    float: none;
    text-align: left;
    width: 100%;
  
    }
  
    .form-line {
      margin-top: 12px;
      margin-bottom: 12px;
    }
  
    .form-all {
      max-width: 752px;
      width: 100%;
    }
  
    .form-label.form-label-left,
    .form-label.form-label-right,
    .form-label.form-label-left.form-label-auto,
    .form-label.form-label-right.form-label-auto {
      width: 230px;
    }
  
    .form-all {
      font-size: 16px
    }
    .form-all .qq-upload-button,
    .form-all .qq-upload-button,
    .form-all .form-submit-button,
    .form-all .form-submit-reset,
    .form-all .form-submit-print {
      font-size: 16px
    }
    .form-all .form-pagebreak-back-container,
    .form-all .form-pagebreak-next-container {
      font-size: 16px
    }
  
    .supernova .form-all, .form-all {
      background-color: #fff;
    }
  
    .form-all {
      color: #2C3345;
    }
    .form-header-group .form-header {
      color: #2C3345;
    }
    .form-header-group .form-subHeader {
      color: #2C3345;
    }
    .form-label-top,
    .form-label-left,
    .form-label-right,
    .form-html,
    .form-checkbox-item label,
    .form-radio-item label {
      color: #2C3345;
    }
    .form-sub-label {
      color: #464d5f;
    }
  
    .supernova {
      background-color: #ecedf3;
    }
    .supernova body {
      background: transparent;
    }
  
    .form-textbox,
    .form-textarea,
    .form-dropdown,
    .form-radio-other-input,
    .form-checkbox-other-input,
    .form-captcha input,
    .form-spinner input {
      background-color: #fff;
    }
  
      .supernova {
        height: 100%;
        background-repeat: no-repeat;
        background-attachment: fixed;
        background-position: center top;
      }
      .supernova {
        background-image: url("https://www.jotform.com/uploads/coxwm11/form_files/bg.626174a5471e67.74787991.jpg");
      }
      #stage {
        background-image: url("https://www.jotform.com/uploads/coxwm11/form_files/bg.626174a5471e67.74787991.jpg");
      }
    
    .form-all {
      background-image: none;
    }
  
    .form-all {
      position: relative;
    }
    .form-all:before {
      content: "";
      background-image: url("https://www.jotform.com/uploads/coxwm11/form_files/MSCS-Logo-Color-Transparent-Bkg.626165916199c7.52685291.png");
      display: inline-block;
      height: 144.24242424242px;
      position: absolute;
      background-size: 170px 144px;
      background-repeat: no-repeat;
      width: 100%;
    }
    .form-all {
      margin-top: 164px !important;
    }
    .form-all:before {
      top: -154px;
      background-position: top center;
      left: 0;
    }
           
  .ie-8 .form-all:before { display: none; }
  .ie-8 {
    margin-top: auto;
    margin-top: initial;
  }
  
  /*PREFERENCES STYLE*//*__INSPECT_SEPERATOR__*/
    /* Injected CSS Code */
</style>

<script src="https://cdn01.jotfor.ms/static/prototype.forms.js" type="text/javascript"></script>
<script src="https://cdn02.jotfor.ms/static/jotform.forms.js?3.3.32842" type="text/javascript"></script>
<script src="https://cdn03.jotfor.ms/js/vendor/jquery-1.8.0.min.js?v=3.3.32842" type="text/javascript"></script>
<script defer src="https://cdn01.jotfor.ms/js/vendor/maskedinput.min.js?v=3.3.32842" type="text/javascript"></script>
<script defer src="https://cdn02.jotfor.ms/js/vendor/jquery.maskedinput.min.js?v=3.3.32842" type="text/javascript"></script>
<script type="text/javascript">	JotForm.newDefaultTheme = true;
	JotForm.extendsNewTheme = false;
	JotForm.newPaymentUIForNewCreatedForms = true;
	JotForm.newPaymentUI = true;
	JotForm.clearFieldOnHide="disable";
	JotForm.submitError="jumpToFirstError";

	JotForm.init(function(){
	/*INIT-START*/

 JotForm.calendarMonths = ["January","February","March","April","May","June","July","August","September","October","November","December"];
 JotForm.calendarDays = ["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"];
 JotForm.calendarOther = {"today":"Today"};
 var languageOptions = document.querySelectorAll('#langList li'); 
 for(var langIndex = 0; langIndex < languageOptions.length; langIndex++) { 
   languageOptions[langIndex].on('click', function(e) { setTimeout(function(){ JotForm.setCalendar("4", false, {"days":{"monday":true,"tuesday":true,"wednesday":true,"thursday":true,"friday":true,"saturday":true,"sunday":true},"future":true,"past":true,"custom":false,"ranges":false,"start":"","end":""}); }, 0); });
 } 
 JotForm.onTranslationsFetch(function() { JotForm.setCalendar("4", false, {"days":{"monday":true,"tuesday":true,"wednesday":true,"thursday":true,"friday":true,"saturday":true,"sunday":true},"future":true,"past":true,"custom":false,"ranges":false,"start":"","end":""}); });
      setTimeout(function() {
          $('input_13').hint('ex: 23');
       }, 20);
      JotForm.alterTexts(undefined);
	/*INIT-END*/
	});

   JotForm.prepareCalculationsOnTheFly([null,null,null,{"name":"studentDevice","qid":"3","text":"Student Device Request 2022","type":"control_head"},{"description":"","name":"date","qid":"4","text":"Date","type":"control_datetime"},null,{"description":"","name":"selectYour","qid":"6","subLabel":"","text":"Select Your Name.","type":"control_dropdown"},{"description":"","name":"reasonFor","qid":"7","text":"Reason for Request.","type":"control_radio"},{"description":"","name":"selectYour8","qid":"8","subLabel":"","text":"Select Your School.","type":"control_dropdown"},{"description":"","name":"selectThe9","qid":"9","subLabel":"","text":"Select the Student's Grade Level.","type":"control_dropdown"},{"name":"submit","qid":"10","text":"Submit","type":"control_button"},{"description":"","name":"enterStudents","qid":"11","text":"Enter Student's First and Last Name. ","type":"control_fullname"},null,{"description":"","name":"enterThe","qid":"13","subLabel":"","text":"Enter the Student's PowerSchool ID Number. ","type":"control_number"}]);
   setTimeout(function() {
JotForm.paymentExtrasOnTheFly([null,null,null,{"name":"studentDevice","qid":"3","text":"Student Device Request 2022","type":"control_head"},{"description":"","name":"date","qid":"4","text":"Date","type":"control_datetime"},null,{"description":"","name":"selectYour","qid":"6","subLabel":"","text":"Select Your Name.","type":"control_dropdown"},{"description":"","name":"reasonFor","qid":"7","text":"Reason for Request.","type":"control_radio"},{"description":"","name":"selectYour8","qid":"8","subLabel":"","text":"Select Your School.","type":"control_dropdown"},{"description":"","name":"selectThe9","qid":"9","subLabel":"","text":"Select the Student's Grade Level.","type":"control_dropdown"},{"name":"submit","qid":"10","text":"Submit","type":"control_button"},{"description":"","name":"enterStudents","qid":"11","text":"Enter Student's First and Last Name. ","type":"control_fullname"},null,{"description":"","name":"enterThe","qid":"13","subLabel":"","text":"Enter the Student's PowerSchool ID Number. ","type":"control_number"}]);}, 20); 
</script>


<!--Beginning of my code-->



<style> 

/*Search Elements */
.searchTable{
  display: block;
  overflow: scroll;
  height: 500px;
  overflow-y: scroll;
    
}
.searchTable, .searchHeading{
    border: 1px solid #333;
    
    border-collapse: collapse;
    
    
}

.searchData{
    border: 1px solid #333;
    
    border-collapse: collapse;
}
th {
  background: white;
  position: sticky;
  top: 0;
}



/*Navigation Bar*/


.topnav {
  overflow: hidden;
  background-color: #333;
}

.topnav a {
  float: left;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

.topnav a:hover {
  background-color: #ddd;
  color: black;
}

.topnav a.active {
  background-color: blue;
  color: white;
}


/*End of Navigation Bar */

</style>


    <script>
function searchBar() {
  var input, filter, table, tr, td, i, txtValue;
  input = document.getElementById("myInput");
  filter = input.value.toUpperCase();
  table = document.getElementById("myTable");
  tr = table.getElementsByTagName("tr");
  for (i = 0; i < tr.length; i++) {
    td = tr[i].getElementsByTagName("td")[7];
    if (td) {
      txtValue = td.textContent || td.innerText;
      if (txtValue.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    }       
  }
}






</script>

    <script>
function searchBar1() {
  var input, filter, table, tr, td, i, txtValue;
  input = document.getElementById("myInput1");
  filter = input.value.toUpperCase();
  table = document.getElementById("myTable1");
  tr = table.getElementsByTagName("tr");
  for (i = 0; i < tr.length; i++) {
    td = tr[i].getElementsByTagName("td")[7];
    if (td) {
      txtValue = td.textContent || td.innerText;
      if (txtValue.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    }       
  }
}






</script>


<script>
    
    function selectFilter1() {
  var input, filter, table, tr, td, i;
  input = document.getElementById("myList1");
  filter = input.value.toUpperCase();
  table = document.getElementById("myTable1");
  tr = table.getElementsByTagName("tr");
  for (i = 0; i < tr.length; i++) {
    td = tr[i].getElementsByTagName("td")[4];
    if (td) {
      if (td.innerHTML.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    }       
  }
}
</script>


<script>
    
    function selectFilter() {
  var input, filter, table, tr, td, i;
  input = document.getElementById("myList2");
  filter = input.value.toUpperCase();
  table = document.getElementById("myTable");
  tr = table.getElementsByTagName("tr");
  for (i = 0; i < tr.length; i++) {
    td = tr[i].getElementsByTagName("td")[4];
    if (td) {
      if (td.innerHTML.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    }       
  }
}
</script>


<style>
.searchBox{
width: 50%;


}

.searchBox1{
width: 70%;


}


#cid_38{
    background-color:#D3D3D3;
    border: solid 1px;
}
</style>
<!--End of my code-->

</head>
<body>
<form  action="/Student Device Request Files/ErrorPage.php" method="post" name="form_221104092209039" id="221104092209039" accept-charset="utf-8" autocomplete="on" >
  <input type="hidden" name="formID" value="221104092209039" />
  <input type="hidden" id="JWTContainer" value="" />
  <input type="hidden" id="cardinalOrderNumber" value="" />
  <div role="main" class="form-all">
    <div class="formLogoWrapper Center">
      <img loading="lazy" class="formLogoImg" src="https://www.jotform.com/uploads/coxwm11/form_files/MSCS-Logo-Color-Transparent-Bkg.626165916199c7.52685291.png" height="144" width="170">
    </div>
    <style>
      .formLogoWrapper { display:inline-block; position: absolute; width: 100%;} .form-all:before { background: none !important;} .formLogoWrapper.Center { top: -154px; text-align: center;}
    </style>
    
    <div class="topnav">
  <a class="active" href="http://www.velgoodies.com/Student%20Device%20Request%20Files/Form.php">Home</a>
  <a href="http://velgoodies.com/Student%20Device%20Request%20Files/Digital_Device_Ambassador_Dashboard.php" > DD Ambassador Dashboard</a>
  <a href="https://scstn.powerschool.com/admin" target = "_blank">PowerSchool</a>
  <a href="https://student1-1devicetheftloss.scsk12.org/" target = "_blank">Theft, Damage and Vandalism</a>
</div>
    <ul class="form-section page-section">
      <li id="cid_3" class="form-input-wide" data-type="control_head">
        <div class="form-header-group  header-large">
          <div class="header-text httal htvam">
            <h1 id="header_3" class="form-header" data-component="header">
              Student Device Request 2022
            </h1>
            <p> <b>NOTE:</b> 
For Damaged, Lost or Stolen Device Replacement: Before a device is approved for delivery, the school must have completed a <u>Theft, Damage and Vandalism report </u>that includes an <u>uploaded receipt</u> or <u>approved Device Cost Relief form</u>. In addition, the student <b>cannot</b> have a 1:1 or loaner device on their PowerSchool record.</p>
          </div>
        </div>
      </li>
       <li class="form-line jf-required" data-type="control_datetime" id="id_4">
        <label class="form-label form-label-top form-label-auto" id="label_4" for="lite_mode_4">
          Date
          <span class="form-required">
            *
          </span>
        </label>
        <div id="cid_4" class="form-input-wide jf-required" data-layout="half">
          <div data-wrapper-react="true">
            <div style="display:none">
              <span class="form-sub-label-container" style="vertical-align:top">
                <input type="tel" class="form-textbox validate[required, limitDate]" id="year_4" name="q4_date[year]" size="4" data-maxlength="4" data-age="" maxLength="4" value="2022" required="" autoComplete="section-input_4 off" aria-labelledby="label_4 sublabel_4_year" />
                <span class="date-separate" aria-hidden="true">
                   -
                </span>
                <label class="form-sub-label" for="year_4" id="sublabel_4_year" style="min-height:13px" aria-hidden="false"> Year </label>
              </span>
              <span class="form-sub-label-container" style="vertical-align:top">
                <input type="tel" class="form-textbox validate[required, limitDate]" id="month_4" name="q4_date[month]" size="2" data-maxlength="2" data-age="" maxLength="2" value="05" required="" autoComplete="section-input_4 off" aria-labelledby="label_4 sublabel_4_month" />
                <span class="date-separate" aria-hidden="true">
                   -
                </span>
                <label class="form-sub-label" for="month_4" id="sublabel_4_month" style="min-height:13px" aria-hidden="false"> Month </label>
              </span>
              <span class="form-sub-label-container" style="vertical-align:top">
                <input type="tel" class="currentDate form-textbox validate[required, limitDate]" id="day_4" name="q4_date[day]" size="2" data-maxlength="2" data-age="" maxLength="2" value="02" required="" autoComplete="section-input_4 off" aria-labelledby="label_4 sublabel_4_day" />
                <label class="form-sub-label" for="day_4" id="sublabel_4_day" style="min-height:13px" aria-hidden="false"> Day </label>
              </span>
            </div>
            <span class="form-sub-label-container" style="vertical-align:top">
              <input type="text" name ="tDate" class="form-textbox validate[required, limitDate, validateLiteDate]" id="lite_mode_4" size="12" data-maxlength="12" maxLength="12" data-age="" value="2022-05-02" required="" data-format="yyyymmdd" data-seperator="-" placeholder="YYYY-MM-DD" autoComplete="section-input_4 off" aria-labelledby="label_4 sublabel_4_litemode" readonly/>
             
              <label class="form-sub-label" for="lite_mode_4" id="sublabel_4_litemode" style="min-height:13px" aria-hidden="false"> Date </label>
            </span>
          </div>
        </div>
      </li>
      <li class="form-line jf-required" data-type="control_dropdown" id="id_6">
        <label class="form-label form-label-top form-label-auto" id="label_6" for="input_6">
          Select Your Name.
          <span class="form-required">
            *
          </span>
        </label>
        <div id="cid_6" class="form-input-wide jf-required" data-layout="half">
          <select class="form-dropdown validate[required]" id="input_6" name="q6_selectYour" style="width:310px" data-component="dropdown" required="">
            <option value=""> Please Select </option>
          
            <option value = " Aeria Mcghee ">Aeria Mcghee </option>
<option value = " Allen Moody ">Allen Moody </option>
<option value = " Anana Johnson">Anana Johnson</option>
<option value = " Andreas Hibbler ">Andreas Hibbler </option>
<option value = " Angela Freeman ">Angela Freeman </option>
<option value = " Angelique Moffett">Angelique Moffett</option>
<option value = " Atina Jones">Atina Jones</option>
<option value = " Atongela Boga">Atongela Boga</option>
<option value = " Aurelia Hickman">Aurelia Hickman</option>
<option value = " Autumn Scott ">Autumn Scott </option>
<option value = " Bobbi Cowell ">Bobbi Cowell </option>
<option value = " Brandy Colvin">Brandy Colvin</option>
<option value = " Brandy Powell ">Brandy Powell </option>
<option value = " Candaya Jenkins ">Candaya Jenkins </option>
<option value = " Canita Oliphant-Hall ">Canita Oliphant-Hall </option>
<option value = " Carla Sohns ">Carla Sohns </option>
<option value = " Carol Schwam">Carol Schwam</option>
<option value = " Cassandra Taylor ">Cassandra Taylor </option>
<option value = " Cathy Doyle ">Cathy Doyle </option>
<option value = " Cemillare Lester ">Cemillare Lester </option>
<option value = " Chanda Crenshaw">Chanda Crenshaw</option>
<option value = " Charlotte White ">Charlotte White </option>
<option value = " Cherica Crawford">Cherica Crawford</option>
<option value = " Cherice Robertson ">Cherice Robertson </option>
<option value = " Cherim Williams ">Cherim Williams </option>
<option value = " Christina Littlefield ">Christina Littlefield </option>
<option value = " Christopher Graham ">Christopher Graham </option>
<option value = " Courtney Jordan ">Courtney Jordan </option>
<option value = " Crystal Thigpen ">Crystal Thigpen </option>
<option value = " Cynthia Brewer ">Cynthia Brewer </option>
<option value = " Cynthia Mayfield ">Cynthia Mayfield </option>
<option value = " D'Tavieus Taylor">D'Tavieus Taylor</option>
<option value = " Damon Friends ">Damon Friends </option>
<option value = " Daniel Lee">Daniel Lee</option>
<option value = " Daniel Robertson">Daniel Robertson</option>
<option value = " Deborah Dodson">Deborah Dodson</option>
<option value = " Delia Young">Delia Young</option>
<option value = " Donna Lee">Donna Lee</option>
<option value = " Dorsi Scott ">Dorsi Scott </option>
<option value = " Ebony Suggs">Ebony Suggs</option>
<option value = " Elexus Franklin ">Elexus Franklin </option>
<option value = " Elizabeth Jackson ">Elizabeth Jackson </option>
<option value = " Elizabeth Marable ">Elizabeth Marable </option>
<option value = " Embassy Swift ">Embassy Swift </option>
<option value = " Erick DeSquare">Erick DeSquare</option>
<option value = " Erin Thornsberry ">Erin Thornsberry </option>
<option value = " Fatima Ellis-Clark">Fatima Ellis-Clark</option>
<option value = " Fay Broughton">Fay Broughton</option>
<option value = " Flora Colunga">Flora Colunga</option>
<option value = " Gary Patrick ">Gary Patrick </option>
<option value = " Haley Dunavant">Haley Dunavant</option>
<option value = " Hosieethe Hughes ">Hosieethe Hughes </option>
<option value = " Hunter Thompson">Hunter Thompson</option>
<option value = " Jacqueline Fleming-Maxwell">Jacqueline Fleming-Maxwell</option>
<option value = " Jada Rainey">Jada Rainey</option>
<option value = " Jamie Bridges ">Jamie Bridges </option>
<option value = " Jean Murchison ">Jean Murchison </option>
<option value = " Jennifer Jackson">Jennifer Jackson</option>
<option value = " Jeremy Smith ">Jeremy Smith </option>
<option value = " John Moon ">John Moon </option>
<option value = " Kacy Barber ">Kacy Barber </option>
<option value = " Karyn Martin ">Karyn Martin </option>
<option value = " Kathryn Downey-Smith">Kathryn Downey-Smith</option>
<option value = " Kedrick Cottrell ">Kedrick Cottrell </option>
<option value = " Kelly George ">Kelly George </option>
<option value = " Kenya Nichols">Kenya Nichols</option>
<option value = " Keyonna Banks">Keyonna Banks</option>
<option value = " Kima Ransom">Kima Ransom</option>
<option value = " Kimberly Davis">Kimberly Davis</option>
<option value = " Kimberly Williams ">Kimberly Williams </option>
<option value = " Kortney Goodwin ">Kortney Goodwin </option>
<option value = " La Fonde Wooden ">La Fonde Wooden </option>
<option value = " LaCandace Campbell">LaCandace Campbell</option>
<option value = " Lakisha Evans ">Lakisha Evans </option>
<option value = " Latarra L Rallings">Latarra L Rallings</option>
<option value = " Latashia McCullum ">Latashia McCullum </option>
<option value = " Laura Ginsberg">Laura Ginsberg</option>
<option value = " Laura Peacock">Laura Peacock</option>
<option value = " Lauren Sullivan ">Lauren Sullivan </option>
<option value = " LeAnn Dowty">LeAnn Dowty</option>
<option value = " Leigh Ann Summerville">Leigh Ann Summerville</option>
<option value = " LeighAnne Frazier">LeighAnne Frazier</option>
<option value = " Letedrick Wiggins">Letedrick Wiggins</option>
<option value = " Lisa Hall ">Lisa Hall </option>
<option value = " Lisa Perkins ">Lisa Perkins </option>
<option value = " LJillauna Smith">LJillauna Smith</option>
<option value = " Lori Streeter">Lori Streeter</option>
<option value = " Major Boyce ">Major Boyce </option>
<option value = " Malorie Tuggers ">Malorie Tuggers </option>
<option value = " Marlon Killebrew">Marlon Killebrew</option>
<option value = " Marquita Rice ">Marquita Rice </option>
<option value = " Marvin Moore">Marvin Moore</option>
<option value = " Mary Greer ">Mary Greer </option>
<option value = " Mary Myrick">Mary Myrick</option>
<option value = " Mary S Beaudry">Mary S Beaudry</option>
<option value = " Megan Oconnor">Megan Oconnor</option>
<option value = " Melissa Jamerson">Melissa Jamerson</option>
<option value = " Melva Hawkins ">Melva Hawkins </option>
<option value = " Michelle Kornberger ">Michelle Kornberger </option>
<option value = " Mikia Felder">Mikia Felder</option>
<option value = " Monica Fransioli">Monica Fransioli</option>
<option value = " Morgan Kesler">Morgan Kesler</option>
<option value = " Mycha Williams-Gladney ">Mycha Williams-Gladney </option>
<option value = " Natasha Nunnally ">Natasha Nunnally </option>
<option value = " Nevenia Hill ">Nevenia Hill </option>
<option value = " Nicole Espree ">Nicole Espree </option>
<option value = " Nikki Hardy">Nikki Hardy</option>
<option value = " Patricia Cooper ">Patricia Cooper </option>
<option value = " Patricia Lockhart ">Patricia Lockhart </option>
<option value = " Patricia Stephens ">Patricia Stephens </option>
<option value = " Percy Hunter ">Percy Hunter </option>
<option value = " Quennel Anderson">Quennel Anderson</option>
<option value = " Rachel Brinkley-Green">Rachel Brinkley-Green</option>
<option value = " Rachel Conwill">Rachel Conwill</option>
<option value = " Rahja Jones">Rahja Jones</option>
<option value = " Raven Redmond">Raven Redmond</option>
<option value = " Regina Williams ">Regina Williams </option>
<option value = " Retha Bell ">Retha Bell </option>
<option value = " Ronetta Shivers ">Ronetta Shivers </option>
<option value = " Sandra Allen ">Sandra Allen </option>
<option value = " Sharhonda Gales">Sharhonda Gales</option>
<option value = " Sharlet Huff">Sharlet Huff</option>
<option value = " Shatara Johnson-Terry ">Shatara Johnson-Terry </option>
<option value = " Sherita Thomas">Sherita Thomas</option>
<option value = " Shirley Blache">Shirley Blache</option>
<option value = " Shirley Lowery ">Shirley Lowery </option>
<option value = " Stephanie Carr">Stephanie Carr</option>
<option value = " Stephanie Kissell">Stephanie Kissell</option>
<option value = " Susan Harris">Susan Harris</option>
<option value = " Susan Satar">Susan Satar</option>
<option value = " Talisha Burnett">Talisha Burnett</option>
<option value = " Tamara Lewis">Tamara Lewis</option>
<option value = " Tamara Sutton ">Tamara Sutton </option>
<option value = " Tami Spears">Tami Spears</option>
<option value = " Tara Seals">Tara Seals</option>
<option value = " Teresa Ulrich ">Teresa Ulrich </option>
<option value = " Terrye Stepter">Terrye Stepter</option>
<option value = " Tiffany Smith ">Tiffany Smith </option>
<option value = " Tina Johnson">Tina Johnson</option>
<option value = " Tonya R. Walton">Tonya R. Walton</option>
<option value = " Tracey Jones ">Tracey Jones </option>
<option value = " Troy Stagner ">Troy Stagner </option>
<option value = " Veranda Moffett">Veranda Moffett</option>
<option value = " Vernice Bowles ">Vernice Bowles </option>
<option value = " Whitney Eavenson ">Whitney Eavenson </option>
<option value = " Yvonne Starks ">Yvonne Starks </option>
<option value = " Zina Henry ">Zina Henry </option>
<option value = " Zucchineus Carruth">Zucchineus Carruth</option>
          </select>
        </div>
      </li>
      <li class="form-line jf-required" data-type="control_dropdown" id="id_8">
        <label class="form-label form-label-top form-label-auto" id="label_8" for="input_8">
          Select Your School.
          <span class="form-required">
            *
          </span>
        </label>
        <div id="cid_8" class="form-input-wide jf-required" data-layout="half">
          <select class="form-dropdown validate[required]" id="input_8" name="q8_selectYour8" style="width:310px" data-component="dropdown" required="">
            <option value=""> Please Select </option>
            <option value="A. B. Hill ES "> A. B. Hill ES </option>
            <option value="A. Maceo Walker MS "> A. Maceo Walker MS </option>
            <option value="Adolescent Parenting Program  "> Adolescent Parenting Program </option>
            <option value="Airways Achievement Academy "> Airways Achievement Academy </option>
            <option value="Alcy ES "> Alcy ES </option>
            <option value="Alton ES "> Alton ES </option>
            <option value="American Way MS "> American Way MS </option>
            <option value="Avon Lennox HS "> Avon Lennox HS </option>
            <option value="Balmoral-Ridgeway ES "> Balmoral-Ridgeway ES </option>
            <option value="Barret&#x27;s Chapel K-8 "> Barret&#x27;s Chapel K-8 </option>
            <option value="Belle Forest ES "> Belle Forest ES </option>
            <option value="Bellevue MS "> Bellevue MS </option>
            <option value="Berclair ES "> Berclair ES </option>
            <option value="Bethel Grove ES "> Bethel Grove ES </option>
            <option value="Bolton HS "> Bolton HS </option>
            <option value="Booker T. Washington MS "> Booker T. Washington MS </option>
            <option value="Brewster ES "> Brewster ES </option>
            <option value="Brownsville Road ES "> Brownsville Road ES </option>
            <option value="Bruce ES "> Bruce ES </option>
            <option value="Central HS "> Central HS </option>
            <option value="Cherokee ES "> Cherokee ES </option>
            <option value="Chickasaw MS "> Chickasaw MS </option>
            <option value="Chimneyrock ES "> Chimneyrock ES </option>
            <option value="Colonial MS "> Colonial MS </option>
            <option value="Cordova ES "> Cordova ES </option>
            <option value="Cordova HS "> Cordova HS </option>
            <option value="Cordova MS "> Cordova MS </option>
            <option value="Craigmont HS "> Craigmont HS </option>
            <option value="Craigmont MS "> Craigmont MS </option>
            <option value="Cromwell ES "> Cromwell ES </option>
            <option value="Crump ES "> Crump ES </option>
            <option value="Cummings K-8 "> Cummings K-8 </option>
            <option value="Delano ES "> Delano ES </option>
            <option value="Dexter ES "> Dexter ES </option>
            <option value="Dexter MS "> Dexter MS </option>
            <option value="Double Tree ES "> Double Tree ES </option>
            <option value="Douglass HS "> Douglass HS </option>
            <option value="Douglass K-8 "> Douglass K-8 </option>
            <option value="Downtown ES "> Downtown ES </option>
            <option value="Dunbar ES "> Dunbar ES </option>
            <option value="East High STEM  "> East High STEM </option>
            <option value="EE Jeter K-8 "> EE Jeter K-8 </option>
            <option value="Egypt ES "> Egypt ES </option>
            <option value="Evans ES "> Evans ES </option>
            <option value="Ford Road ES "> Ford Road ES </option>
            <option value="Fox Meadows ES "> Fox Meadows ES </option>
            <option value="G.W. Carver Career Academy "> G.W. Carver Career Academy </option>
            <option value="Gardenview ES "> Gardenview ES </option>
            <option value="Geeter K-8 "> Geeter K-8 </option>
            <option value="Georgian Hills MS "> Georgian Hills MS </option>
            <option value="Germanshire ES "> Germanshire ES </option>
            <option value="Germantown ES "> Germantown ES </option>
            <option value="Germantown HS "> Germantown HS </option>
            <option value="Germantown MS "> Germantown MS </option>
            <option value="Getwell ES "> Getwell ES </option>
            <option value="Gordon Achievement Academy "> Gordon Achievement Academy </option>
            <option value="Grahamwood ES "> Grahamwood ES </option>
            <option value="Grandview Heights MS "> Grandview Heights MS </option>
            <option value="Hamilton HS "> Hamilton HS </option>
            <option value="Hamilton K-8 "> Hamilton K-8 </option>
            <option value="Havenivew MS "> Havenivew MS </option>
            <option value="Hawkins Mill ES "> Hawkins Mill ES </option>
            <option value="Hickory Ridge ES "> Hickory Ridge ES </option>
            <option value="Hickory Ridge MS "> Hickory Ridge MS </option>
            <option value="Highland Oaks ES "> Highland Oaks ES </option>
            <option value="Highland Oaks MS "> Highland Oaks MS </option>
            <option value="Hollis F. Price HS "> Hollis F. Price HS </option>
            <option value="Holmes Road ES "> Holmes Road ES </option>
            <option value="Hope Academy"> Hope Academy </option>
            <option value="Ida B. Wells Academy "> Ida B. Wells Academy </option>
            <option value="Idlewild ES "> Idlewild ES </option>
            <option value="J.P. Freeman K-8 "> J.P. Freeman K-8 </option>
            <option value="Jackson ES "> Jackson ES </option>
            <option value="Kate Bond ES "> Kate Bond ES </option>
            <option value="Kate Bond MS "> Kate Bond MS </option>
            <option value="Keystone ES "> Keystone ES </option>
            <option value="Kingsbury ES "> Kingsbury ES </option>
            <option value="Kingsbury HS "> Kingsbury HS </option>
            <option value="Kingsbury MS "> Kingsbury MS </option>
            <option value="Kirby HS "> Kirby HS </option>
            <option value="LaRose ES "> LaRose ES </option>
            <option value="Levi ES  "> Levi ES </option>
            <option value="Lowrance K-8 "> Lowrance K-8 </option>
            <option value="Lucie E. Campbell ES "> Lucie E. Campbell ES </option>
            <option value="Lucy ES "> Lucy ES </option>
            <option value="Macon Hall ES "> Macon Hall ES </option>
            <option value="Manassas HS "> Manassas HS </option>
            <option value="Maxine Smith MS "> Maxine Smith MS </option>
            <option value="Medical District HS"> Medical District HS </option>
            <option value="Melrose HS "> Melrose HS </option>
            <option value="Memphis Virtual School"> Memphis Virtual School </option>
            <option value="Middle College HS "> Middle College HS </option>
            <option value="Mitchell HS "> Mitchell HS </option>
            <option value="Mt. Pisgah MS "> Mt. Pisgah MS </option>
            <option value="New Comers International Ctr "> New Comers International Ctr </option>
            <option value="Newberry ES "> Newberry ES </option>
            <option value="Northaven ES "> Northaven ES </option>
            <option value="Northeast Prep Academy "> Northeast Prep Academy </option>
            <option value="Northwest Prep Academy  "> Northwest Prep Academy </option>
            <option value="Oak Forest ES "> Oak Forest ES </option>
            <option value="Oakhaven ES "> Oakhaven ES </option>
            <option value="Oakhaven HS "> Oakhaven HS </option>
            <option value="Oakhaven MS "> Oakhaven MS </option>
            <option value="Oakshire ES "> Oakshire ES </option>
            <option value="Overton HS "> Overton HS </option>
            <option value="Parkway Village ES "> Parkway Village ES </option>
            <option value="Peabody ES "> Peabody ES </option>
            <option value="Raleigh Bartlett Meadows ES "> Raleigh Bartlett Meadows ES </option>
            <option value="Raleigh Egypt HS "> Raleigh Egypt HS </option>
            <option value="Raleigh Egypt MS "> Raleigh Egypt MS </option>
            <option value="Richland ES "> Richland ES </option>
            <option value="Ridgeway HS "> Ridgeway HS </option>
            <option value="Ridgeway MS "> Ridgeway MS </option>
            <option value="Riverview K-8 "> Riverview K-8 </option>
            <option value="Riverwood ES "> Riverwood ES </option>
            <option value="Robert R. Church ES "> Robert R. Church ES </option>
            <option value="Ross ES "> Ross ES </option>
            <option value="Rozelle ES "> Rozelle ES </option>
            <option value="Scenic Hills ES "> Scenic Hills ES </option>
            <option value="Sea Isle ES "> Sea Isle ES </option>
            <option value="Shady Grove ES "> Shady Grove ES </option>
            <option value="Sharpe ES "> Sharpe ES </option>
            <option value="Sheffield ES "> Sheffield ES </option>
            <option value="Sheffield HS "> Sheffield HS </option>
            <option value="Shelby Oaks ES "> Shelby Oaks ES </option>
            <option value="Sherwood ES "> Sherwood ES </option>
            <option value="Sherwood MS "> Sherwood MS </option>
            <option value="Shrine School "> Shrine School </option>
            <option value="Snowden K-8 "> Snowden K-8 </option>
            <option value="South Park ES "> South Park ES </option>
            <option value="Southwind ES "> Southwind ES </option>
            <option value="Southwind HS "> Southwind HS </option>
            <option value="Springdale ES "> Springdale ES </option>
            <option value="Treadwell ES "> Treadwell ES </option>
            <option value="Treadwell MS "> Treadwell MS </option>
            <option value="Trezevant HS "> Trezevant HS </option>
            <option value="Vollentine ES "> Vollentine ES </option>
            <option value="Wells Station ES "> Wells Station ES </option>
            <option value="Westhaven ES "> Westhaven ES </option>
            <option value="Westside ES "> Westside ES </option>
            <option value="Westwood HS "> Westwood HS </option>
            <option value="White Station ES "> White Station ES </option>
            <option value="White Station HS "> White Station HS </option>
            <option value="White Station MS "> White Station MS </option>
            <option value="Whitehaven ES "> Whitehaven ES </option>
            <option value="Whitehaven HS "> Whitehaven HS </option>
            <option value="Willow Oaks ES "> Willow Oaks ES </option>
            <option value="Winchester ES "> Winchester ES </option>
            <option value="Winridge ES "> Winridge ES </option>
            <option value="Wooddale HS "> Wooddale HS </option>
            <option value="Woodstock MS "> Woodstock MS </option>
          </select>
        </div>
      </li>
      <li class="form-line jf-required" data-type="control_dropdown" id="id_9">
        <label class="form-label form-label-top form-label-auto" id="label_9" for="input_9">
          Select the Student's Grade Level.
          <span class="form-required">
            *
          </span>
        </label>
        <div id="cid_9" class="form-input-wide jf-required" data-layout="half">
          <select class="form-dropdown validate[required]" id="input_9" name="q9_selectThe9" style="width:310px" data-component="dropdown" required="">
            <option value=""> Please Select </option>
            <option value="0"> KK </option>
            <option value="1"> 1 </option>
            <option value="2"> 2 </option>
            <option value="3"> 3 </option>
            <option value="4"> 4 </option>
            <option value="5"> 5 </option>
            <option value="6"> 6 </option>
            <option value="7"> 7 </option>
            <option value="8"> 8 </option>
            <option value="9"> 9 </option>
            <option value="10"> 10 </option>
            <option value="11"> 11 </option>
            <option value="12"> 12 </option>
          </select>
        </div>
      </li>
      <li class="form-line jf-required" data-type="control_radio" id="id_7">
        <label class="form-label form-label-top form-label-auto" id="label_7" for="input_7">
          Reason for Request.
          <span class="form-required">
            *
          </span>
        </label>
        <div id="cid_7" class="form-input-wide jf-required" data-layout="full">
          <div class="form-single-column" role="group" aria-labelledby="label_7" data-component="radio">
            <span class="form-radio-item" style="clear:left">
              <span class="dragger-item">
              </span>
              <input type="radio" aria-describedby="label_7" class="form-radio validate[required]" id="input_7_0" name="q7_reasonFor" value="Replacement Device for Damage, Lost or Stolen (Only submit request for students that have paid the $75 replacement fee)" required="" />
              <label id="label_input_7_0" for="input_7_0"> Replacement Device for Damage, Lost or Stolen (Only submit request for students that have paid the $75 replacement fee) </label>
            </span>
            <span class="form-radio-item" style="clear:left">
              <span class="dragger-item">
              </span>
              <input type="radio" aria-describedby="label_7" class="form-radio validate[required]" id="input_7_1" name="q7_reasonFor" value="IT Warranty Replacement" required="" />
              <label id="label_input_7_1" for="input_7_1"> IT Warranty Replacement </label>
            </span>
            <span class="form-radio-item" style="clear:left">
              <span class="dragger-item">
              </span>
              <input type="radio" aria-describedby="label_7" class="form-radio validate[required]" id="input_7_2" name="q7_reasonFor" value="New to the District (Student has never been issued a 1:1 device by MSCS)" required="" />
              <label id="label_input_7_2" for="input_7_2"> <b>(K - 8 Only)</b> New to the District (Student has never been issued a 1:1 device by MSCS) </label>
            </span>
            <span class="form-radio-item" style="clear:left">
              <span class="dragger-item">
              </span>
              <input type="radio" aria-describedby="label_7" class="form-radio validate[required]" id="input_7_3" name="q7_reasonFor" value=" New to the District/Transfer Student/Incoming 9th Grader" required="" />
              <label id="label_input_7_3" for="input_7_3"> <b>(9 - 12 Only)</b> New to the District/Transfer Student/Incoming 9th Grader </label>
            </span>
            <span class="form-radio-item" style="clear:left">
              <span class="dragger-item">
              </span>
              <input type="radio" aria-describedby="label_7" class="form-radio validate[required]" id="input_7_4" name="q7_reasonFor" value="(9 - 12 Only) ECF Device Request" required="" />
              <label id="label_input_7_4" for="input_7_4"><b> (9 - 12 Only)</b> ECF Device Request </label>
            </span>
          </div>
        </div>
      </li>
      <li class="form-line jf-required" data-type="control_fullname" id="id_11">
        <label class="form-label form-label-top form-label-auto" id="label_11" for="first_11">
          Enter Student's First and Last Name.
          <span class="form-required">
            *
          </span>
        </label>
        <div id="cid_11" class="form-input-wide jf-required" data-layout="full">
          <div data-wrapper-react="true">
            <span class="form-sub-label-container" style="vertical-align:top" data-input-type="first">
              <input type="text" id="first_11" name="firstName" class="form-textbox validate[required]" data-defaultvalue="" autoComplete="section-input_11 given-name" size="10" value="" data-component="first" aria-labelledby="label_11 sublabel_11_first" required="" />
              <label class="form-sub-label" for="first_11" id="sublabel_11_first" style="min-height:13px" aria-hidden="false"> First Name </label>
            </span>
            <span class="form-sub-label-container" style="vertical-align:top" data-input-type="last">
              <input type="text" id="last_11" name="lastName" class="form-textbox validate[required]" data-defaultvalue="" autoComplete="section-input_11 family-name" size="15" value="" data-component="last" aria-labelledby="label_11 sublabel_11_last" required="" />
              <label class="form-sub-label" for="last_11" id="sublabel_11_last" style="min-height:13px" aria-hidden="false"> Last Name </label>
            </span>
          </div>
        </div>
      </li>
      <li class="form-line jf-required" data-type="control_number" id="id_13">
        <label class="form-label form-label-top form-label-auto" id="label_13" for="input_13">
          Enter the Student's PowerSchool ID Number.
          <span class="form-required">
            *
          </span>
        </label>
        <div id="cid_13" class="form-input-wide jf-required" data-layout="half">
          <input type="number" id="input_13" name="q13_enterThe" data-type="input-number" class=" form-number-input form-textbox validate[required]" data-defaultvalue="" style="width:310px" size="310" value="" placeholder="ex: 23" data-component="number" aria-labelledby="label_13" required="" maxlength="6"  step="any" />
        </div>
      </li>
      <li class="form-line" data-type="control_button" id="id_10">
        <div id="cid_10" class="form-input-wide" data-layout="full">
          <div data-align="auto" class="form-buttons-wrapper form-buttons-auto   jsTest-button-wrapperField">
            <button id="input_10" type="submit" class="form-submit-button submit-button jf-form-buttons jsTest-submitField" data-component="button" data-content="">
              Submit
            </button>
          </div>
        </div>
      </li>
      

      <li style="display:none">
        Should be Empty:
        <input type="text" name="website" value="" />
      </li>
    </ul>
  </div>
  <script>
  JotForm.showJotFormPowered = "new_footer";
  </script>
  <script>
  JotForm.poweredByText = "Powered by Jotform";
  </script>
  <input type="hidden" class="simple_spc" id="simple_spc" name="simple_spc" value="221104092209039" />
  <script type="text/javascript">
  var all_spc = document.querySelectorAll("form[id='221104092209039'] .si" + "mple" + "_spc");
for (var i = 0; i < all_spc.length; i++)
{
  all_spc[i].value = "221104092209039-221104092209039";
}
  </script>
  <div class="formFooter-heightMask">
  </div>

</form></body>
</html>





