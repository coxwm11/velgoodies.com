<?php 
//Form Variables 
$tDate = $_POST['tDate'];
$schoolName = $_POST['q7_selectThe'];
$gradeLevel = $_POST['q10_selectThe10'];
$studentFirstName = $_POST['firstName'];
$studentLastName = $_POST['lastName'];
$psid = $_POST['q11_enterThe'];
$Addressed = "N";
$SearchEntries = $_POST['q3_selectField'];
$startDate = $_POST['startDate'];
$endDate = $_POST['endDate'];
$associateName = $_POST['q8_selectThe8'];
$DDAName = $_POST['q9_selectThe9'];
$Response = $_POST['q12_selectApproval'];
$responseUpdate = $_POST['q19_selectApproval19'];
$schoolNameUpdate = $_POST['q17_selectStudents'];
$psidUpdate = $_POST['q16_enterStudents'];
$denialReasonUpdate = $_POST['q21_reasonFor'];
$formIDstart = $_POST ['q27_enterBeginning27'];
$formIDend = $_POST ['q29_enterEnding'];
$deviceStatus = $_POST['q26_selectThe26'];
$school2= $_POST['q30_selectSchool'];
$approval2 = $_POST['q32_approvalStatus'];
$gradeLevel2 = $_POST['q33_selectStudents33'];
$formID2 = $_POST['q49_enterThe49'];


// Load the database configuration file 
//Database Connection

$db_host = 'localhost:3306';
$db_name = 'coxwm11_SDRForm';
$db_user = 'coxwm11_VEL';
$db_pw = 'Ethel1908!!!';
    
  
    
$conn = new mysqli($db_host, $db_user, $db_pw, $db_name );

if($conn-> connect_error){
    
    die('Connection Failed : '.$conn -> connect_error);
   
} else{
    
     // Fetch records from database 
$query = $conn->query( "SELECT * FROM `Student Device Request` WHERE `labelStatus` = 'Label Not Created' AND `Response` != 'DENIED' AND `Addressed`='Y' ORDER BY `School` ASC, `Grade` ASC; "); 
 
if($query->num_rows > 0){ 
    $delimiter = ","; 
    $filename = "student-device-request-labels_" . date('Y-m-d') . ".csv"; 
     
    // Create a file pointer 
    $f = fopen('php://memory', 'w'); 
     
    // Set column headers 
    $fields = array('formID', 'Addressed', 'Date', 'Ambassador', 'School Name', 'Grade', 'PSID', 'Student First Name', 'Student Last Name', 'Reason', 'Response'); 
    fputcsv($f, $fields, $delimiter); 
     
    // Output each row of the data, format line as csv and write to file pointer 
    while($row = $query->fetch_assoc()){ 
        $lineData = array($row['formID'], $row['Addressed'], $row['Date'], $row['DDAName'], $row['School'], $row['Grade'], $row['PSID'], $row['FirstName'], $row['LastName'], $row['Reason'], $row['Response']); 
        fputcsv($f, $lineData, $delimiter); 
    } 
     
    // Move back to beginning of file 
    fseek($f, 0); 
     
    // Set headers to download file rather than displayed 
    header('Content-Type: text/csv'); 
    header('Content-Disposition: attachment; filename="' . $filename . '";'); 
     
    //output all remaining data on a file pointer 
    fpassthru($f); 
}//beginning if statment 

exit;
     
     
     
 
}//beginning else statement 
 
?>