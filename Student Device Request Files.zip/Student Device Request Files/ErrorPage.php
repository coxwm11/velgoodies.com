<!DOCTYPE html>
<html>
    
 <head>
<title> Student Device Request</title>

<script src="https://cdn01.jotfor.ms/static/prototype.forms.js" type="text/javascript"></script>
<script src="https://cdn02.jotfor.ms/static/jotform.forms.js?3.3.32845" type="text/javascript"></script>
<script type="text/javascript">	JotForm.newDefaultTheme = true;
	JotForm.extendsNewTheme = false;
	JotForm.newPaymentUIForNewCreatedForms = true;
	JotForm.newPaymentUI = true;
	JotForm.clearFieldOnHide="disable";
	JotForm.submitError="jumpToFirstError";

	JotForm.init(function(){
	/*INIT-START*/
      JotForm.alterTexts(undefined);
	/*INIT-END*/
	});

   JotForm.prepareCalculationsOnTheFly([null,null,null,{"name":"studentDevice","qid":"3","text":"Student Device Request 2022","type":"control_head"},null,null,null,null,null,null,null,null,null,null,null,{"description":"","labelText":"","name":"oops626198fb78537193564717","qid":"15","text":"oops.626198fb785371.93564717","type":"control_image"}]);
   setTimeout(function() {
JotForm.paymentExtrasOnTheFly([null,null,null,{"name":"studentDevice","qid":"3","text":"Student Device Request 2022","type":"control_head"},null,null,null,null,null,null,null,null,null,null,null,{"description":"","labelText":"","name":"oops626198fb78537193564717","qid":"15","text":"oops.626198fb785371.93564717","type":"control_image"}]);}, 20); 
</script>
<style type="text/css">@media print{.form-section{display:inline!important}.form-pagebreak{display:none!important}.form-section-closed{height:auto!important}.page-section{position:initial!important}}</style>
<link type="text/css" rel="stylesheet" href="https://cdn01.jotfor.ms/themes/CSS/5e6b428acc8c4e222d1beb91.css?themeRevisionID=5f7ed99c2c2c7240ba580251"/>
<link type="text/css" rel="stylesheet" href="https://cdn02.jotfor.ms/css/styles/payment/payment_styles.css?3.3.32845" />
<link type="text/css" rel="stylesheet" href="https://cdn03.jotfor.ms/css/styles/payment/payment_feature.css?3.3.32845" />
<style type="text/css" id="form-designer-style">
    /* Injected CSS Code */
/*PREFERENCES STYLE*/
    .form-all {
      font-family: Inter, sans-serif;
    }
    .form-all .qq-upload-button,
    .form-all .form-submit-button,
    .form-all .form-submit-reset,
    .form-all .form-submit-print {
      font-family: Inter, sans-serif;
    }
    .form-all .form-pagebreak-back-container,
    .form-all .form-pagebreak-next-container {
      font-family: Inter, sans-serif;
    }
    .form-header-group {
      font-family: Inter, sans-serif;
    }
    .form-label {
      font-family: Inter, sans-serif;
    }
  
    .form-label.form-label-auto {
      
    display: block;
    float: none;
    text-align: left;
    width: 100%;
  
    }
  
    .form-line {
      margin-top: 12px;
      margin-bottom: 12px;
    }
  
    .form-all {
      max-width: 752px;
      width: 100%;
    }
  
    .form-label.form-label-left,
    .form-label.form-label-right,
    .form-label.form-label-left.form-label-auto,
    .form-label.form-label-right.form-label-auto {
      width: 230px;
    }
  
    .form-all {
      font-size: 16px
    }
    .form-all .qq-upload-button,
    .form-all .qq-upload-button,
    .form-all .form-submit-button,
    .form-all .form-submit-reset,
    .form-all .form-submit-print {
      font-size: 16px
    }
    .form-all .form-pagebreak-back-container,
    .form-all .form-pagebreak-next-container {
      font-size: 16px
    }
  
    .supernova .form-all, .form-all {
      background-color: #fff;
    }
  
    .form-all {
      color: #2C3345;
    }
    .form-header-group .form-header {
      color: #2C3345;
    }
    .form-header-group .form-subHeader {
      color: #2C3345;
    }
    .form-label-top,
    .form-label-left,
    .form-label-right,
    .form-html,
    .form-checkbox-item label,
    .form-radio-item label {
      color: #2C3345;
    }
    .form-sub-label {
      color: #464d5f;
    }
  
    .supernova {
      background-color: #ecedf3;
    }
    .supernova body {
      background: transparent;
    }
  
    .form-textbox,
    .form-textarea,
    .form-dropdown,
    .form-radio-other-input,
    .form-checkbox-other-input,
    .form-captcha input,
    .form-spinner input {
      background-color: #fff;
    }
  
      .supernova {
        height: 100%;
        background-repeat: repeat;
        background-attachment: scroll;
        background-position: center top;
      }
      .supernova {
        background-image: url("https://www.jotform.com/uploads/coxwm11/form_files/bg.626174a5471e67.74787991.jpg");
      }
      #stage {
        background-image: url("https://www.jotform.com/uploads/coxwm11/form_files/bg.626174a5471e67.74787991.jpg");
      }
    
    .form-all {
      background-image: none;
    }
  
    .form-all {
      position: relative;
    }
    .form-all:before {
      content: "";
      background-image: url("https://www.jotform.com/uploads/coxwm11/form_files/MSCS-Logo-Color-Transparent-Bkg.626165916199c7.52685291.png");
      display: inline-block;
      height: 144.24242424242px;
      position: absolute;
      background-size: 170px 144px;
      background-repeat: no-repeat;
      width: 100%;
    }
    .form-all {
      margin-top: 164px !important;
    }
    .form-all:before {
      top: -154px;
      background-position: top center;
      left: 0;
    }
           
  .ie-8 .form-all:before { display: none; }
  .ie-8 {
    margin-top: auto;
    margin-top: initial;
  }
  
  /*PREFERENCES STYLE*//*__INSPECT_SEPERATOR__*/
    /* Injected CSS Code */
</style>

 </head>  
 
 <body>

  <input type="hidden" name="formID" value="221104920532139" />
  <input type="hidden" id="JWTContainer" value="" />
  <input type="hidden" id="cardinalOrderNumber" value="" />
  <div role="main" class="form-all">
    <div class="formLogoWrapper Center">
      <img loading="lazy" class="formLogoImg" src="https://www.jotform.com/uploads/coxwm11/form_files/MSCS-Logo-Color-Transparent-Bkg.626165916199c7.52685291.png" height="144" width="170">
    </div>
    <style>
      .formLogoWrapper { display:inline-block; position: absolute; width: 100%;} .form-all:before { background: none !important;} .formLogoWrapper.Center { top: -154px; text-align: center;}
    </style>
    <ul class="form-section page-section">
      <li id="cid_3" class="form-input-wide" data-type="control_head">
        <div class="form-header-group  header-large">
          <div class="header-text httal htvam">
            <h1 id="header_3" class="form-header" data-component="header">
              Student Device Request 2022
            </h1>
          </div>
        </div>
      </li>
      <li class="form-line" data-type="control_image" id="id_15">
        <div id="cid_15" class="form-input-wide" data-layout="full">
        
        </div>
      </li>
      
            <?php
//Form Variables 
$tDate = $_POST['tDate'];
$DDAName = $_POST['q6_selectYour'];
$schoolName = $_POST['q8_selectYour8'];
$gradeLevel = $_POST['q9_selectThe9'];
$reason = $_POST['q7_reasonFor'];
$studentFirstName = $_POST['firstName'];
$studentLastName = $_POST['lastName'];
$psid = $_POST['q13_enterThe'];
$Addressed = "N";
$labelStatus = "Label Not Created";
$processed = "Device Not Processed and Shipped";




//Database Connection

$db_host = 'localhost:3306';
$db_name = 'coxwm11_SDRForm';
$db_user = 'coxwm11_VEL';
$db_pw = 'Ethel1908!!!';

$conn = new mysqli($db_host, $db_user, $db_pw, $db_name );


if($conn-> connect_error){
    die('Connection Failed : '.$conn -> connect_error);
    
   
}else{
   
     $result = mysqli_query ($conn, "SELECT * FROM `Student Device Request` WHERE `PSID` = \"$psid\" AND `Addressed` = 'N' ");
     
      if((mysqli_num_rows($result) > 0)){
         echo" <button onclick=history.go(-1) style = 'background-color: yellow; '>Go Back to Check Submission</button>";
         
          echo"<table border = 1px text-align=center>";

               echo"<tr>";
         
          echo "<td text-align=center>";
          
           echo "<h3 style='color:red; text-align:center;'> Oops! Your request was not submitted. There is a duplicate request for this student currently. Please review the information below and resubmit your request.</h3> ";
          echo "</td>";
          echo"</tr>";
          echo"</table>";
          
          
         
          
    
         
         echo "<br>";
        echo" ";
          
          //echo submission stuff for student
          
           echo "<table  width =100% border = 1px text-align=center>";
           
echo "<colgroup>";      
      echo "<col width =100px>";
echo "<col width =100px>";
echo "<col >";
echo "<col >";
echo "<col >";
echo "<col >";
echo "<col >";

echo "</colgroup>"; 

echo "<tr>"; 
echo "<th> Date </th>";
echo "<th> Device Ambassador </th>";
echo "<th> School </th>";
echo "<th> Student Grade </th>";
echo "<th> Reason for Request </th>";
echo "<th> Student Name</th>";
echo "<th> PSID </th>";
echo "</tr>";

while($row = $result->fetch_assoc()) {
    
echo "<tr >";
echo "<td  >" . $row['Date'] . "</td>";
echo "<td style=text-align:center; >" . $row['DDAName'] . "</td>";
echo "<td  >" . $row['School'] . "</td>";
echo "<td style=text-align:center; >" . $row['Grade'] . "</td>";
echo "<td  >" . $row['Reason'] . "</td>";
echo "<td  >" . $row['FirstName'] . " " . $row['LastName'] ."</td>";
echo "<td  >" . $row['PSID'] . "</td>";

echo "</tr>";

    
}

  echo "</table>";
 

$result-> close();



          
      }
      
      else{


          
          $stmt = $conn->prepare ("INSERT into `Student Device Request` (Addressed, Date, DDAName, School, Grade, Reason, FirstName, LastName, PSID, labelStatus, processed) VALUES (?,?,?,?,?,?,?,?,?,?,?)");
          
          $stmt->bind_param('ssssisssiss',$Addressed, $tDate, $DDAName, $schoolName, $gradeLevel, $reason, $studentFirstName, $studentLastName, $psid, $labelStatus, $processed);
          
    $stmt-> execute();
    $stmt-> close();
    
    echo"<table text-align=center>";
    echo"<tr>";
    echo"<td>";
    
      echo"<h3 style='color:green; text-align:center;'>  Your submission has been recived.</h3>";
    
    echo"</td>";
      echo"<td>";
       echo "<button onClick= \"location.href = 'https://velgoodies.com/Student%20Device%20Request%20Files/Form.php' \">Submit Another Request </button>";
     
    
    echo"</td>";
    
    echo"<tr>";
    echo"</table>";
    
  
   
    
 
    
          
      }
      
      
      
      
      
   
    
    $conn->close(); 
     
    
    
}

 


?>








      <li style="display:none">
        Should be Empty:
        <input type="text" name="website" value="" />
      </li>
    </ul>
  </div>
  <script>
  JotForm.showJotFormPowered = "new_footer";
  </script>
  <script>
  JotForm.poweredByText = "Powered by Jotform";
  </script>
  <input type="hidden" class="simple_spc" id="simple_spc" name="simple_spc" value="221104920532139" />
  <script type="text/javascript">
  var all_spc = document.querySelectorAll("form[id='221104920532139'] .si" + "mple" + "_spc");
for (var i = 0; i < all_spc.length; i++)
{
  all_spc[i].value = "221104920532139-221104920532139";
}
  </script>
  <div class="formFooter-heightMask">
  </div>

  
  </body>

</html>