<?php



//Form Variables 


$schoolName = $_POST['q8_selectYour8'];
$psid = $_POST['q3_studentsPsid'];
$Addressed = "Y";
$Response = $_POST['q4_selectThe'];
$DenialReason = $_POST['q7_reasonFor'];
$DDAssociate = $_POST['q14_deviceAssociate'];




//Database Connection

$db_host = 'localhost:3306';
$db_name = 'coxwm11_SDRForm';
$db_user = 'coxwm11_VEL';
$db_pw = 'Ethel1908!!!';

$conn = new mysqli($db_host, $db_user, $db_pw, $db_name );


if($conn-> connect_error){
    die('Connection Failed : '.$conn -> connect_error);
    }else{
        
        $result = mysqli_query($conn, "SELECT * FROM `Student Device Request` WHERE `PSID` = \"$psid\" AND `Addressed` = 'N' ");
        
        if((mysqli_num_rows($result) > 0)){
            
           $stmt = $conn->prepare ("UPDATE `Student Device Request` SET `Response`= '$Response', `DenialReason` = '$DenialReason', `Addressed` = '$Addressed', `AssociateName` = '$DDAssociate', `labelStatus` = 'Label Not Created', `processed` = 'Device Not Processed and Shipped' WHERE `PSID` ='$psid' "); 
           
    $stmt-> execute();
    $stmt-> close();
    
       echo '<h3><font color = green> Your submission has been received.</font></h3>';
    
  echo "<button onClick= \"location.href = 'https://www.velgoodies.com/DDA%20Vett%20Form/Student_Device_Request_DDA_Review.html' \">Review Another Request. </button>";

        }
        
        else{


    echo '<h3><font color = red> Ooops! There is no student with this PSID that has not been addressed. Please review your submission. </font></h3>';
    
     echo" <button onclick=history.go(-1) style = background-color: red color:white>Go Back to Correct Form </button>";
          
      }
          $conn->close(); 
      
        
    }

        
    ?>