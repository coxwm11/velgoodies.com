<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html lang="en-US"  class="supernova"><head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="alternate" type="application/json+oembed" href="https://www.jotform.com/oembed/?format=json&amp;url=https%3A%2F%2Fform.jotform.com%2F221106862477053" title="oEmbed Form">
<link rel="alternate" type="text/xml+oembed" href="https://www.jotform.com/oembed/?format=xml&amp;url=https%3A%2F%2Fform.jotform.com%2F221106862477053" title="oEmbed Form">
<meta property="og:title" content="Student Device Request DDA Review" >
<meta property="og:url" content="https://form.jotform.com/221106862477053" >
<meta property="og:description" content="Please click the link to complete this form." >
<meta name="slack-app-id" content="AHNMASS8M">
<link rel="shortcut icon" href="https://cdn.jotfor.ms/assets/img/favicons/favicon-2021.svg">
<link rel="canonical" href="https://form.jotform.com/221106862477053" />
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=2.0, user-scalable=1" />
<meta name="HandheldFriendly" content="true" />
<title>Student Device Request DDA Review</title>
<style type="text/css">@media print{.form-section{display:inline!important}.form-pagebreak{display:none!important}.form-section-closed{height:auto!important}.page-section{position:initial!important}}</style>
<link type="text/css" rel="stylesheet" href="https://cdn01.jotfor.ms/themes/CSS/5e6b428acc8c4e222d1beb91.css?themeRevisionID=5f7ed99c2c2c7240ba580251"/>
<link type="text/css" rel="stylesheet" href="https://cdn02.jotfor.ms/css/styles/payment/payment_styles.css?3.3.32846" />
<link type="text/css" rel="stylesheet" href="https://cdn03.jotfor.ms/css/styles/payment/payment_feature.css?3.3.32846" />

<style type="text/css" id="form-designer-style">
    /* Injected CSS Code */

  
  
  
  
  
  
  /*PREFERENCES STYLE*/
  /* NEW THEME STYLE */

  /* colors */

  .form-textbox, .form-textarea {
    color: undefined;
  }
  .rating-item input:hover+label {
    color: rgba(18, 69, 141, 0.75);
  }
  li[data-type=control_fileupload] .qq-upload-button,
  .until-text,
  .form-submit-reset {
    color: rgba(18, 69, 141, 0.75);
  }

  .stageEmpty.isSmall{
    color: rgba(18, 69, 141, 0.75);
  }

  .rating-item label {
    color: rgba(18, 69, 141, 0.75);
  }
  .currentDate,
  .pickerItem select,
  .appointmentCalendar .calendarDay,
  .calendar.popup th,
  .calendar.popup table tbody td,
  .calendar-new-header>*,
  .form-collapse-table {
    color: #12458D;
  }
  .appointmentCalendar .dayOfWeek {
    color: #12458D;
  }
  .appointmentSlotsContainer > * {
    color: rgba(18, 69, 141, 0.75);
  }
  li[data-type=control_fileupload] .jfUpload-heading,
  ::placeholder,
  .form-dropdown.is-active,
  .form-dropdown:first-child,
  .form-spinner-input {
    color: #5B95E6;
  }
  .appointmentCalendar .calendarWeek .calendarDay.isUnavailable,
  .calendar tr.days td.otherDay,
  .calendar tr.days td:hover:not(.unselectable) {
    color: #5B95E6;
  }
  span.form-sub-label, label.form-sub-label, div.form-header-group .form-subHeader,
  .rating-item-title.for-to > label:first-child,
  .rating-item-title.for-from > label:first-child,
  .rating-item-title .editor-container * {
    color: #12458D;
  }
  .form-pagebreak-back{
    color: #FFFFFF;
  }
  .rating-item input:checked+label,
  .rating-item input:focus+label {
    color: #FFFFFF;
  }
  .clear-pad-btn {
    color: #FFFFFF;
  }
  .form-textbox::placeholder,
  .form-dropdown:not(.time-dropdown):not(:required),
  .form-dropdown:not(:required),
  .form-dropdown:required:invalid {
    color: #5B95E6;
  }
  /* border-colors */
  .form-dropdown,
  .form-textarea,
  .form-textbox,
  li[data-type=control_fileupload] .qq-upload-button,
  .rating-item label,
  .rating-item input:focus+label,
  .rating-item input:checked+label,
  .jf-form-buttons,
  .form-checkbox+label:before, .form-checkbox+span:before, .form-radio+label:before, .form-radio+span:before,
  .signature-pad-passive,
  .signature-wrapper,
  .appointmentCalendarContainer,
  .appointmentField .timezonePickerName,
  .appointmentDayPickerButton,
  .appointmentCalendarContainer .monthYearPicker .pickerItem+.pickerItem,
  .appointmentCalendarContainer .monthYearPicker,
  .appointmentCalendar .calendarDay.isActive .calendarDayEach, .appointmentCalendar .calendarDay.isToday .calendarDayEach, .appointmentCalendar .calendarDay:not(.empty):hover .calendarDayEach,
  .calendar.popup:before,
  .calendar-new-month,
  .form-matrix-column-headers, .form-matrix-table td, .form-matrix-table td:last-child,
  .form-matrix-table th, .form-matrix-table th:last-child, .form-matrix-table tr:last-child td, .form-matrix-table tr:last-child th, .form-matrix-table tr:not([role=group])+tr[role=group] th,
  .form-matrix-headers.form-matrix-column-headers,
  .isSelected .form-matrix-column-headers:nth-last-of-type(2),
  li[data-type=control_inline] input[type=email], li[data-type=control_inline] input[type=number],
  li[data-type=control_inline] input[type=tel], li[data-type=control_inline] input[type=text],
  .stageEmpty.isSmall {
    border-color: rgba(18, 69, 141, 0.75);
  }
  .rating-item input:hover+label {
    border-color: rgba(18, 69, 141, 0.75);
  }
  .appointmentSlot,
  .form-checkbox:checked+label:before, .form-checkbox:checked+span:before, .form-checkbox:checked+span label:before,
  .form-radio:checked+label:before, .form-radio:checked+span:before,
  .form-dropdown:focus, .form-textarea:focus, .form-textbox:focus, .signature-wrapper:focus,
  .form-line[data-payment="true"] .form-product-item .p_checkbox .checked,
  .form-dropdown:hover, .form-textarea:hover, .form-textbox:hover, .signature-wrapper:hover {
    border-color: rgba(18, 69, 141, 0.75);
  }

  .calendar tr.days td:hover:not(.unselectable):after {
    border-color: #5B95E6;
  }
  .form-header-group,
  .form-buttons-wrapper, .form-pagebreak, .form-submit-clear-wrapper,
  .form-pagebreak-next,
  .form-pagebreak-back,
  .form-checkbox:hover+label:before, .form-checkbox:hover+span:before, .form-radio:hover+label:before, .form-radio:hover+span:before,
  .divider {
    border-color: #2462B9;
  }
  .form-pagebreak-back:focus, .form-pagebreak-next:focus, .form-submit-button:focus {
    border-color: rgba(18, 69, 141, 1);
  }
  /* background-colors */
  .form-line-active {
    background-color: #FFFFFF;
  }
  .form-line-error {
    background-color: #FFD6D6;
  }
  .form-matrix-column-headers, .form-matrix-row-headers,
  .form-spinner-button-container>*,
  .form-collapse-table,
  .form-collapse-table:hover,
  .appointmentDayPickerButton {
    background-color: #5B95E6;
  }
  .calendar.popup, .calendar.popup table,
  .calendar.popup table tbody td:after{
    background-color: #E4EFFF;
  }

  .appointmentCalendar .calendarDay.isActive .calendarDayEach,
  .appointmentFieldRow.forSelectedDate,
  .calendar.popup tr.days td.selected:after,
  .calendar.popup:after,
  .submit-button,
  .form-checkbox:checked+label:before, .form-checkbox:checked+span:before, .form-checkbox:checked+span label:before,
  .form-radio+label:after, .form-radio+span:after,
  .rating-item input:checked+label,
  .appointmentCalendar .calendarDay:after,
  .form-line[data-payment="true"] .form-product-item .p_checkbox .checked,
  .rating-item input:focus+label {
    background-color: #093A80;
  }
  .appointmentSlot.active {
    background-color: #093A80 !important;
  }
  .clear-pad-btn,
  .appointmentCalendar .dayOfWeek,
  .calendar.popup th {
    background-color: #2462B9 !important;
  }
  .appointmentField .timezonePicker:hover+.timezonePickerName,
  .form-spinner-button-container>*:hover {
    background-color: #849DBF;
  }
  .form-matrix-values,
  .form-matrix-values,
  .signature-wrapper,
  .signature-pad-passive,
  .rating-item label,
  .form-checkbox+label:before, .form-checkbox+span:before,
  .form-radio+label:before, .form-radio+span:before {
    background-color: #FFFFFF;
  }
  li[data-type=control_fileupload] .qq-upload-button {
    background-color: #FFFFFF;
  }
  .JotFormBuilder .appContainer #app li.form-line[data-type=control_matrix].isSelected
  .questionLine-editButton.forRemove:after, 
  .JotFormBuilder .appContainer #app li.form-line[data-type=control_matrix].isSelected .questionLine-editButton.forRemove:before {
    background-color: #FFFFFF;
  }
  .appointmentCalendarContainer, .appointmentSlot,
  .rating-item-title.for-to > label:first-child,
  .rating-item-title.for-from > label:first-child,
  .rating-item-title .editor-container *,
  .calendar-opened {
    background-color: transparent;
  }
  .page-section li.form-line-active[data-type="control_button"] {
    background-color: #FFFFFF;
  }
  .appointmentCalendar .calendarDay.isSelected:after {
    color: #FFFFFF;
  }
  /* shadow */
  .form-dropdown:hover, .form-textarea:hover, .form-textbox:hover, .signature-wrapper:hover,
  .calendar.popup:before,
  .jSignature:hover,
  li[data-type=control_fileupload] .qq-upload-button-hover,
  .form-line[data-payment="true"] .form-product-item .p_checkbox .checked,
  .form-line[data-payment="true"] .form-product-item .p_checkbox:hover .select_border,
  .form-checkbox:hover+label:before, .form-checkbox:hover+span:before, .form-radio:hover+label:before, .form-radio:hover+span:before,
  .calendar.popup:before {
    border-color: rgba(18, 69, 141, 0.5);
    box-shadow: 0 0 0 2px rgba(18, 69, 141, 0.25);
  }
  .form-dropdown:focus, .form-textarea:focus, .form-textbox:focus, .signature-wrapper:focus,
  li[data-type=control_fileupload] .qq-upload-button-focus,
  .form-checkbox:focus+label:before, .form-checkbox:focus+span:before, .form-radio:focus+label:before, .form-radio:focus+span:before,
  .calendar.popup:before {
    border-color: rgba(18, 69, 141, 1);
    box-shadow: 0 0 0 3px rgba(18, 69, 141, 0.25);
  }
  .calendar.popup table tbody td{
    box-shadow: none;
  }

  /* button colors */
  .submit-button {
    background-color: #12458D;
    border-color: #12458D;
  }
  .submit-button:hover {
    background-color: #0B2955;
    border-color: #0B2955;
  }
  .form-pagebreak-next {
    background-color: #2462B9;
  }
  .form-pagebreak-back {
    background-color: #2462B9;
  }
  .form-pagebreak-back:hover {
    background-color: #163B6F;
    border-color: #163B6F;
  }
  .form-pagebreak-next:hover {
    background-color: #163B6F;
    border-color: #163B6F;
  }
  .form-sacl-button, .form-submit-print {
    background-color: transparent;
    color: rgba(18, 69, 141, 0.75);
    border-color: rgba(18, 69, 141, 0.75);
  }
  .form-sacl-button:hover, .form-submit-print:hover,
  .appointmentSlot:not(.disabled):not(.active):hover,
  .appointmentDayPickerButton:hover,
  .rating-item input:hover+label {
    background-color: #849DBF;
  }

  /* payment styles */
  
  .form-line[data-payment=true] .form-textbox,
  .form-line[data-payment=true] .select-area,
  .form-line[data-payment=true] #coupon-input,
  .form-line[data-payment=true] #coupon-container input,
  .form-line[data-payment=true] input#productSearch-input,
  .form-line[data-payment=true] .form-product-category-item:after,
  .form-line[data-payment=true] .filter-container .dropdown-container .select-content,
  .form-line[data-payment=true] .form-textbox.form-product-custom_quantity,
  .form-line[data-payment="true"] .form-product-item .p_checkbox .select_border,
  .form-line[data-payment="true"] .form-product-item .form-product-container .form-sub-label-container span.select_cont,
  .form-line[data-payment=true] select.form-dropdown,
  .form-line[data-payment=true] #payment-category-dropdown .select-area,
  .form-line[data-payment=true] #payment-sorting-products-dropdown .select-area,
  .form-line[data-payment=true] .dropdown-container .select-content {
    border-color: rgba(18, 69, 141, 0.75);
    border-color: rgba(18,69,141,.4);
  }
  .form-line[data-payment="true"] hr,
  .form-line[data-payment=true] .p_item_separator,
  .form-line[data-payment="true"] .payment_footer.new_ui,
  .form-line.card-3col .form-product-item.new_ui,
  .form-line.card-2col .form-product-item.new_ui {
    border-color: rgba(18, 69, 141, 0.75);
    border-color: rgba(18,69,141,.2);
  }
  .form-line[data-payment=true] .form-product-category-item {
    border-color: rgba(18, 69, 141, 0.75);
    border-color: rgba(18,69,141,.3);
  }
  .form-line[data-payment=true] #coupon-input,
  .form-line[data-payment=true] .form-textbox.form-product-custom_quantity,
  .form-line[data-payment=true] input#productSearch-input,
  .form-line[data-payment=true] .select-area,
  .form-line[data-payment=true] .custom_quantity,
  .form-line[data-payment=true] .filter-container .select-content,
  .form-line[data-payment=true] .p_checkbox .select_border,
  .form-line[data-payment=true] #payment-category-dropdown .select-area,
  .form-line[data-payment=true] #payment-sorting-products-dropdown .select-area,
  .form-line[data-payment=true] .dropdown-container .select-content {
    background-color: #FFFFFF;
  }
  .form-line[data-payment=true] .form-product-category-item.title_collapsed.has_selected_product .selected-items-icon {
   background-color: rgba(18,69,141,.7);
   border-color: rgba(18,69,141,.7);
  }
  .form-line[data-payment=true].form-line.card-3col .form-product-item,
  .form-line[data-payment=true].form-line.card-2col .form-product-item {
   background-color: rgba(0,0,0,.05);
  }
  .form-line[data-payment=true] .payment-form-table input.form-textbox,
  .form-line[data-payment=true] .payment-form-table input.form-dropdown,
  .form-line[data-payment=true] .payment-form-table .form-sub-label-container > div,
  .form-line[data-payment=true] .payment-form-table span.form-sub-label-container iframe,
  .form-line[data-type=control_square] .payment-form-table span.form-sub-label-container iframe {
    border-color: rgba(18, 69, 141, 0.75);
  }

  /* icons */
  .appointmentField .timezonePickerName:before {
    background-image: url(data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTYiIGhlaWdodD0iMTYiIHZpZXdCb3g9IjAgMCAxNiAxNiIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPHBhdGggZmlsbC1ydWxlPSJldmVub2RkIiBjbGlwLXJ1bGU9ImV2ZW5vZGQiIGQ9Ik0wIDcuOTYwMkMwIDMuNTY2MTcgMy41NTgyMSAwIDcuOTUyMjQgMEMxMi4zNTQyIDAgMTUuOTIwNCAzLjU2NjE3IDE1LjkyMDQgNy45NjAyQzE1LjkyMDQgMTIuMzU0MiAxMi4zNTQyIDE1LjkyMDQgNy45NTIyNCAxNS45MjA0QzMuNTU4MjEgMTUuOTIwNCAwIDEyLjM1NDIgMCA3Ljk2MDJaTTEuNTkzNzUgNy45NjAyQzEuNTkzNzUgMTEuNDc4NiA0LjQ0MzUgMTQuMzI4NCA3Ljk2MTkxIDE0LjMyODRDMTEuNDgwMyAxNC4zMjg0IDE0LjMzMDEgMTEuNDc4NiAxNC4zMzAxIDcuOTYwMkMxNC4zMzAxIDQuNDQxNzkgMTEuNDgwMyAxLjU5MjA0IDcuOTYxOTEgMS41OTIwNEM0LjQ0MzUgMS41OTIwNCAxLjU5Mzc1IDQuNDQxNzkgMS41OTM3NSA3Ljk2MDJaIiBmaWxsPSIjNUI5NUU2Ii8+CjxwYXRoIGQ9Ik04LjM1ODA5IDMuOTc5OThINy4xNjQwNlY4Ljc1NjFMMTEuMzQzMiAxMS4yNjM2TDExLjk0MDIgMTAuMjg0NUw4LjM1ODA5IDguMTU5MDhWMy45Nzk5OFoiIGZpbGw9IiM1Qjk1RTYiLz4KPC9zdmc+Cg==);
  }
  .appointmentCalendarContainer .monthYearPicker .pickerArrow.prev:after {
    background-image: url(data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTAiIGhlaWdodD0iNiIgdmlld0JveD0iMCAwIDEwIDYiIGZpbGw9Im5vbmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+CjxwYXRoIGQ9Ik04LjU5NzgyIDUuMzM2NjRDOC45MzMxMiA1LjY0MDE4IDkuNDM5MzkgNS42MzM2IDkuNzU2MTMgNS4zMTY2OUMxMC4wODEzIDQuOTkxMzYgMTAuMDgxMyA0LjQ2MzU0IDkuNzU2MTMgNC4xMzgyMUM5LjYwOTA0IDQuMDAwMjYgOS42MDkwMyA0LjAwMDI2IDkuMDg5NDkgMy41MTUwOUM4LjQzNzQyIDIuOTA2MDkgOC40Mzc0MyAyLjkwNjA5IDcuNjU1MTEgMi4xNzU0N0M2LjA4OTU2IDAuNzEzMzUzIDYuMDg5NTYgMC43MTMzNTIgNS41Njc3MyAwLjIyNjAwN0M1LjI0MTA0IC0wLjA3MDYwMDUgNC43NTA4NSAtMC4wNjk1OTY3IDQuNDMyMzUgMC4yMjU4MzVMMC4yNjI1NCA0LjExODE1Qy0wLjA4MDU0NTkgNC40NTkzNiAtMC4wODcxNzExIDQuOTg3ODggMC4yNDE0NjggNS4zMTY2OUMwLjU1OTU1OCA1LjYzNDk2IDEuMDY5NzUgNS42NDA1OSAxLjM5NzAzIDUuMzM2NTNMNC45OTg5MSAxLjk3NTIyTDguNTk3ODIgNS4zMzY2NFoiIGZpbGw9IiMxMjQ1OEQiLz4KPC9zdmc+Cg==);
  }
  .appointmentCalendarContainer .monthYearPicker .pickerArrow.next:after {
    background-image: url(data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTAiIGhlaWdodD0iNiIgdmlld0JveD0iMCAwIDEwIDYiIGZpbGw9Im5vbmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+CjxwYXRoIGQ9Ik0xLjQwMjE4IDAuMjI2OTE1QzEuMDY2ODcgLTAuMDc2Njg0OSAwLjU2MDYwMiAtMC4wNzAwODQ5IDAuMjQzODY5IDAuMjQ2ODE1Qy0wLjA4MTI4OTggMC41NzIxMTUgLTAuMDgxMjg5OCAxLjEwMDAyIDAuMjQzODY5IDEuNDI1MzJDMC4zOTA5NTYgMS41NjMyMiAwLjM5MDk2NiAxLjU2MzIyIDAuOTEwNTEgMi4wNDg0MkMxLjU2MjU3IDIuNjU3NDIgMS41NjI1NiAyLjY1NzQxIDIuMzQ0ODggMy4zODgwMkMzLjkxMDQ0IDQuODUwMTEgMy45MTA0MyA0Ljg1MDEyIDQuNDMyMjcgNS4zMzc1MkM0Ljc1ODk1IDUuNjM0MTIgNS4yNDkxNSA1LjYzMzEyIDUuNTY3NjQgNS4zMzc3Mkw5LjczNzQ2IDEuNDQ1NDJDMTAuMDgwNSAxLjEwNDEyIDEwLjA4NzEgMC41NzU2MTUgOS43NTg1MyAwLjI0NjgxNUM5LjQ0MDQ0IC0wLjA3MTQ4NDkgOC45MzAyNCAtMC4wNzcwODQ5IDguNjAyOTcgMC4yMjcwMTVMNS4wMDEwOCAzLjU4ODMyTDEuNDAyMTggMC4yMjY5MTVaIiBmaWxsPSIjMTI0NThEIi8+Cjwvc3ZnPgo=);
  }
  .appointmentField .timezonePickerName:after {
    background-image: url(data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTAiIGhlaWdodD0iNiIgdmlld0JveD0iMCAwIDEwIDYiIGZpbGw9Im5vbmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+CjxwYXRoIGQ9Ik0xIDFMNSA1TDkgMSIgc3Ryb2tlPSIjMTI0NThEIiBzdHJva2Utd2lkdGg9IjIiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgc3Ryb2tlLWxpbmVqb2luPSJyb3VuZCIvPgo8L3N2Zz4K);
    width: 11px;
  }
  li[data-type=control_datetime] [data-wrapper-react=true].extended>div+.form-sub-label-container .form-textbox:placeholder-shown,
  li[data-type=control_datetime] [data-wrapper-react=true]:not(.extended) .form-textbox:not(.time-dropdown):placeholder-shown,
  .appointmentCalendarContainer .currentDate {
    background-image: url(data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTciIGhlaWdodD0iMTYiIHZpZXdCb3g9IjAgMCAxNyAxNiIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPHBhdGggZD0iTTE1Ljk0ODkgNVYxNS4wMjZDMTUuOTQ4OSAxNS41NjM5IDE1LjUwMjYgMTYgMTQuOTUyMSAxNkgwLjk5NjgwNUMwLjQ0NjI4NSAxNiAwIDE1LjU2MzkgMCAxNS4wMjZWNUgxNS45NDg5Wk00LjE5MjQ1IDExLjQxNjdIMi4zNzQ3NEwyLjI4NTE1IDExLjQyNDdDMi4xMTA3OCAxMS40NTY1IDEuOTY4MDEgMTEuNTc5MiAxLjkwNzUyIDExLjc0MjJMMS44ODQzNyAxMS44MjY4TDEuODc2MzQgMTEuOTE2N1YxMy42NjY3TDEuODg0MzcgMTMuNzU2NUMxLjkxNjAyIDEzLjkzMTUgMi4wMzg0IDE0LjA3NDcgMi4yMDA4MyAxNC4xMzU0TDIuMjg1MTUgMTQuMTU4NkwyLjM3NDc0IDE0LjE2NjdINC4xOTI0NUw0LjI4MjAzIDE0LjE1ODZDNC40NTY0MSAxNC4xMjY5IDQuNTk5MTggMTQuMDA0MSA0LjY1OTY3IDEzLjg0MTFMNC42ODI4MiAxMy43NTY1TDQuNjkwODUgMTMuNjY2N1YxMS45MTY3TDQuNjgyODIgMTEuODI2OEM0LjY1MTE3IDExLjY1MTkgNC41Mjg3OSAxMS41MDg2IDQuMzY2MzUgMTEuNDQ3OUw0LjI4MjAzIDExLjQyNDdMNC4xOTI0NSAxMS40MTY3Wk04Ljg4MzI5IDExLjQxNjdINy4wNjU1OUw2Ljk3NiAxMS40MjQ3QzYuODAxNjIgMTEuNDU2NSA2LjY1ODg1IDExLjU3OTIgNi41OTgzNyAxMS43NDIyTDYuNTc1MjIgMTEuODI2OEw2LjU2NzE5IDExLjkxNjdWMTMuNjY2N0w2LjU3NTIyIDEzLjc1NjVDNi42MDY4NyAxMy45MzE1IDYuNzI5MjUgMTQuMDc0NyA2Ljg5MTY4IDE0LjEzNTRMNi45NzYgMTQuMTU4Nkw3LjA2NTU5IDE0LjE2NjdIOC44ODMyOUw4Ljk3Mjg4IDE0LjE1ODZDOS4xNDcyNiAxNC4xMjY5IDkuMjkwMDMgMTQuMDA0MSA5LjM1MDUxIDEzLjg0MTFMOS4zNzM2NyAxMy43NTY1TDkuMzgxNyAxMy42NjY3VjExLjkxNjdMOS4zNzM2NyAxMS44MjY4QzkuMzQyMDIgMTEuNjUxOSA5LjIxOTY0IDExLjUwODYgOS4wNTcyIDExLjQ0NzlMOC45NzI4OCAxMS40MjQ3TDguODgzMjkgMTEuNDE2N1pNNC4xOTI0NSA2LjgzMzMzSDIuMzc0NzRMMi4yODUxNSA2Ljg0MTM5QzIuMTEwNzggNi44NzMxNCAxLjk2ODAxIDYuOTk1OTEgMS45MDc1MiA3LjE1ODg3TDEuODg0MzcgNy4yNDM0NkwxLjg3NjM0IDcuMzMzMzNWOS4wODMzM0wxLjg4NDM3IDkuMTczMjFDMS45MTYwMiA5LjM0ODE1IDIuMDM4NCA5LjQ5MTM3IDIuMjAwODMgOS41NTIwNUwyLjI4NTE1IDkuNTc1MjhMMi4zNzQ3NCA5LjU4MzMzSDQuMTkyNDVMNC4yODIwMyA5LjU3NTI4QzQuNDU2NDEgOS41NDM1MyA0LjU5OTE4IDkuNDIwNzUgNC42NTk2NyA5LjI1NzhMNC42ODI4MiA5LjE3MzIxTDQuNjkwODUgOS4wODMzM1Y3LjMzMzMzTDQuNjgyODIgNy4yNDM0NkM0LjY1MTE3IDcuMDY4NTIgNC41Mjg3OSA2LjkyNTI5IDQuMzY2MzUgNi44NjQ2MUw0LjI4MjAzIDYuODQxMzlMNC4xOTI0NSA2LjgzMzMzWk04Ljg4MzI5IDYuODMzMzNINy4wNjU1OUw2Ljk3NiA2Ljg0MTM5QzYuODAxNjIgNi44NzMxNCA2LjY1ODg1IDYuOTk1OTEgNi41OTgzNyA3LjE1ODg3TDYuNTc1MjIgNy4yNDM0Nkw2LjU2NzE5IDcuMzMzMzNWOS4wODMzM0w2LjU3NTIyIDkuMTczMjFDNi42MDY4NyA5LjM0ODE1IDYuNzI5MjUgOS40OTEzNyA2Ljg5MTY4IDkuNTUyMDVMNi45NzYgOS41NzUyOEw3LjA2NTU5IDkuNTgzMzNIOC44ODMyOUw4Ljk3Mjg4IDkuNTc1MjhDOS4xNDcyNiA5LjU0MzUzIDkuMjkwMDMgOS40MjA3NSA5LjM1MDUxIDkuMjU3OEw5LjM3MzY3IDkuMTczMjFMOS4zODE3IDkuMDgzMzNWNy4zMzMzM0w5LjM3MzY3IDcuMjQzNDZDOS4zNDIwMiA3LjA2ODUyIDkuMjE5NjQgNi45MjUyOSA5LjA1NzIgNi44NjQ2MUw4Ljk3Mjg4IDYuODQxMzlMOC44ODMyOSA2LjgzMzMzWk0xMy41NzQxIDYuODMzMzNIMTEuNzU2NEwxMS42NjY4IDYuODQxMzlDMTEuNDkyNSA2Ljg3MzE0IDExLjM0OTcgNi45OTU5MSAxMS4yODkyIDcuMTU4ODdMMTEuMjY2MSA3LjI0MzQ2TDExLjI1OCA3LjMzMzMzVjkuMDgzMzNMMTEuMjY2MSA5LjE3MzIxQzExLjI5NzcgOS4zNDgxNSAxMS40MjAxIDkuNDkxMzcgMTEuNTgyNSA5LjU1MjA1TDExLjY2NjggOS41NzUyOEwxMS43NTY0IDkuNTgzMzNIMTMuNTc0MUwxMy42NjM3IDkuNTc1MjhDMTMuODM4MSA5LjU0MzUzIDEzLjk4MDkgOS40MjA3NSAxNC4wNDE0IDkuMjU3OEwxNC4wNjQ1IDkuMTczMjFMMTQuMDcyNSA5LjA4MzMzVjcuMzMzMzNMMTQuMDY0NSA3LjI0MzQ2QzE0LjAzMjkgNy4wNjg1MiAxMy45MTA1IDYuOTI1MjkgMTMuNzQ4IDYuODY0NjFMMTMuNjYzNyA2Ljg0MTM5TDEzLjU3NDEgNi44MzMzM1oiIGZpbGw9IiM1Qjk1RTYiLz4KPHBhdGggZD0iTTEzLjA1MjIgMS4xMjVIMTUuMDQ1OEMxNS41OTYzIDEuMTI1IDE2LjA0MjYgMS42MDA3IDE2LjA0MjYgMi4xODc1VjRIMC4wOTM3NVYyLjE4NzVDMC4wOTM3NSAxLjYwMDcgMC41NDAwMzUgMS4xMjUgMS4wOTA1NiAxLjEyNUgzLjA4NDE3VjEuMDYyNUMzLjA4NDE3IDAuNDc1Njk3IDMuNTMwNDUgMCA0LjA4MDk3IDBDNC42MzE0OSAwIDUuMDc3NzggMC40NzU2OTcgNS4wNzc3OCAxLjA2MjVWMS4xMjVIMTEuMDU4NlYxLjA2MjVDMTEuMDU4NiAwLjQ3NTY5NyAxMS41MDQ5IDAgMTIuMDU1NCAwQzEyLjYwNTkgMCAxMy4wNTIyIDAuNDc1Njk3IDEzLjA1MjIgMS4wNjI1VjEuMTI1WiIgZmlsbD0iIzVCOTVFNiIvPgo8L3N2Zz4K);
  }
  .form-star-rating-star.Stars {
    background-image: url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAKAAAAAeCAYAAACrDxUoAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAA2tSURBVHgBzZx7cFTVHcd/5z42C2ySGygh6RCyITxmEGSh7RQD2kUBIZ1W1Io6Uxvgj7aOOhQRdMY/snHUtgrFjLYdZ4rG8gcWOj7qiISosy0EtNPykEdrgTwAzQrC3rxIsnvvPT2/u3s2m83eZPfuZuN35k6Se3f398u5n/s95/7OuUvApqas3LEeCKHXDj7+BoyDxjv+NyGHKau2rzUo2URB36w2bTsB46Cuqqr1ApGoq/kfttqAgA0pq3e63d9ytXb2DECwP1yhHtjcBjkUxlecUutASIc+g+Y8Ps+BaForNiGVxHHJYfLKHa1l0wrcF7/q8gebtiyHHCu4ZIlb/vb0VtrTA1qXWlH0ySdtkKYEsCFB030PrroJfnHPYhB0oxZyLIx/U8UUWDy3eFzi8xw0LQxaODQuOZjuC+BetrAMlt083auseNELOZZARJ9cvQbk++8DURBttUHaAOKVP6OksOYBBuAv714MhZPy1uM+yJEwVoErr8YEcE4x5MliTuPzHCjQGj0cBp1BSCnNeQ4UoBYvANSTD1WxkYCQ04sA3U8sLa2Rq6vBsW4dEFf+etwHaSptALn7zZhWAIWuvJy7IHe/gkkOyHOI4+KC3P0YeOaWaxdE99N1zW3ouvn30oXTc+6C3P1IaQmDz2XbBdMC0LzKCTHdjyuXLsjjI4BcuXZBngO6H1euXdB0PwZ9vHLpguh0hLUBuh+XXRdMC8B49+MadEH9VzDGinc/rkEXHPv4PIcocLF9gy449jkkuh9XLl0w3v24uAsKgpRWG6QMIL/ytz10y7Bj6IKKy1mjeHcqMEbi8W+ZXzrsGLqg0yGNafz4HMKhgWHHIlDCmOeQzP24cuGC3P3yNm4cdgxdUHDl1wS93pTbIGUAk7kfF7rgz+9erAiSNmYOkMz9uNAFF80pHtP4PIdE9+OKuuCY5mDlfly5cMFk7scVccGfKEIo9TawrAMq3l+7RYfsoVQoBzAqZkwr3PTu9nVJAURhTdD78G5gNakG9rEnDKqfBEJVuwXSxPgFk/I2rbt9TlIAUVgT3N34H+jqDTVkI36yHBhkmwb6biQFEMWcAfKcE4EIQkOmOZhOKofdIogsvsGcVyhncdcO9N9QqGGYrxElGWp+9B145Yk7Y+9rPnkZfrx1r0oJ+IlhnCQCOaEbVAVNOqH6N6uQpswxnSx7JI2WGwQqxJKSTRNfeTkpgCisCfbWbAAa6GgglJzQRDgJhqEWHTmStA2IsnKnRwTDw+7nPJSQcgLEAwZVykoKlAWVxaa7zZ85FaqXzrKEj4vBB/ubz8OlK11w6vwV8+9LbMOTQQltI5S2s2uo1RDJu7xwaxW/wOVQipUJprtNVSbCrOmKJXxcDD44f1mFrhshuBK8Yf6N20jxR8rBoIZiGBG3QdcxdM0SvliDEgEEUWRjIZExQyJ/C8KobSBQbS1CBhibUizzKAw8du4MQOAwbmL8ZADy83Catf+plqtw+sJVZg790Z8DCOYJZjsqwskw9qsfbvXje4Lfq/KADB6WrYe5UjllebASu8JAU8RZs0x3E+bMAfnWWy3h4zI6AqAdOsR+doBx7hwYgQBQtg9jEwpt7D9oFyi0alR7l0xesSNYvbRSWXpzmQnYglnFwOpseGcL2RL+8xcDnWbDNH92CfYfuaBeb9pShMcwfuX0QqWsON8ErLgIoZPwzhaypasMxs4ojJeudMOFLzpj8XkOuh5WdLNro8C7uNFgS0fMFTmIIIoSg0eKa4Ptx1lsD+tewQQ+Wt4ZTVYAWqmzd4CBGQFy/5HzsKfpbCyHrqplQenWZYq4mN1QMsAQOnDlA8l3QbbEYURA9WPHGKSHVdYiRj2C8eCqeabLlWF9L4vwoeZXRhwUY0QckcbNGxr16FjzZk6JulxeVuFDTS2KOOi8mZNNdxwaP5IDOhY6jK5psfpeNoUuhp+NMSIgDuZgEFIviELE4aJuNxbC84rjRDwfzZ9dxqTqY/kB1BuBrwDHd5LpcqVZhQ8lzJ5tfjbGMF0R4A2xr6XJ361UkY/+3e69xzsX7yZhLIRX3V1b97Gu+au66x9ufYrvx/i01EvaAt3eueWTQRJtzQ6Oqv6wBvs+PgdXr/cOic9zmFi5ijBH8aILjZViY0QCQ3Lobzl4wlm5ul2SpLWmC6cIIF40nrnfhuqqWZCqsCfC83AxoGIOPr7/N5cu+p+c5CL6p//0yivuAOJwwFgIx4g3Hn0M9HPn6wqPHH7KtJp4CO/4rpuN+5yQTSXA50s8Hg+hu7Qg6xdBAny+ZK8ZawgT4PMlHh+EUF5rxk8BwnQBtIKPawiES75vjvuyqQT4fLgv1tdxCD842uKtrqrMGoT4T9//9NuW8MXHRwgvfNHlZWPCrEGI4563/35hRPjiczAhlBmEWvYgxBuRkeDjMiGsWHVSkuXVDELnaBCmAyCHr+3L4IbgR9tesnpdDMJDh7zybbdlDULscvse3zIEPtSQwRaegFDxbSaEa26pBCU/MwjbOzph7bZ9cO7itVFPPo8vTL89axAifOh8wc6+lOLzHCbOzB6EEfgmjAofV3/rwf86K1c0SpLjgdEgTBVArEis3vQmBL7u3qB+vK0BRpEJYdHkrEGI8KHzGe0Xh8CHGjbazxaE7YEIfFZ2b6VsQcjh6+rpTys+zyEbEKYLH1d/S1MgFQhTARDhu2vbPjXYdePhVODjyhaEMfg6AsPgQyUd8WNjXezorH/sd41gVy/uPpo2fPHxu7oH6hs/bQe7Onq6wxZ88TmwQmq9I28C2JXEBvLpwseFxWtKjOXYdWein9X9DYI94eXpwMeFwOgdgfq+Z58Huwrtes0SPpTlLachiA1dPQNgV6dY7c8g9B2wKYyPsxt2dTXYl1F8ngMSZFdmaSeDHCIzKEQlGeSAJTa1abPt2SBWCm+gPd1gVzrW/sKGZRtYAigauruspBDsCgvaOI0ENoXxM6lHFrPaXybxeQ582suOsKCdSQ6R5V04I2K/Loh1XZxSBJsSqegWSkrBrkRW+xPZDIvVcUsA2b/sxSk4u8L34tQW2BTGn1pkv/ubyqbxMonPc+BTcXaE780oB01zZxIftYAVnUXZ4QWbYtOHXmF26nXGROF7KZveszxudYAKZOGCDADEaT029+cGm8L4CJFd4bReJvF5DkYGDogIZ5iDh2YUH2ehijO6CFjvv1CcMxvsSmAzKiy+2/J4sp2KdycIFBckJO+CsUNQu/vNzapzmM+6YDaIX4ifla54/JG6YCwu42Yl7ILtxuc5EJbDSADg2Gyk8ZmhG2YOYFMEhB+MdgFgkX8kZWoEhIJCSqwXH2BxGTcrCbNmI2SWbWDlgEpBvtOD9p0ohO7pP/ph5j1/COL22PYDZr0vEcQZkTllN34WpC/F4ZA8ybpghM5/7DL8/q+fBXE78GmbWXJJlPnMiCy6bcY3c6DoQHQ4AAid7HBC3gSXipsjz5kURHwvG7+5bS9SJaAki4/ChQiy7ID3my+oix76E+w5eCbp65YuLLN9EZgLS10uD47jEoXQ9de/DN13rlFx63/ueaCs5JIowXxmJN9ttUg1OYCS5pmfAB+C91tWWllcsyv46lv/qqOaMJNKwuI9jafr2D7KQYwXDoBxTRukKxY/ET4ED0srr713Nnjs80As/tmWr+t2vXeGJgPRXL5lJ340h8TxlwmenMfAm6RKkog5VLAcFomiWOec6IJkIJo3EDZzYJ/kTXRgvLN2TpgEcp6zjTnb8uCHW4raAuryR7Yf8CcDkRuBrYtA0zyJ4z8Eb2DX69B77zo1tHdvneGQKgxDWxTa/0Fdz733QTIQzeVbvSF3shBWVV4Pn4pD8F595zi8+tYx2tnbX2+ExTrVv5UvbMSfPna31rCn8Uxt88nL+MASeWDFPCgvLTTvhM+0XMXxR7plAI9TjqSG4B3//Coc+/wKHQhrlvHPtlyrvXylBx9YIvMqJpsrP7Ab/lrtsxPfzIHbOkLFisJsMC/jmAhz8AUHF3fGchCp5BMmiDU6y1nTQtE1fDrIgpx2DrhGkJ3Y2MoYBE925AERRQYe8alx38YQXdPnpyt3rH9ke2PtC7uPuvHRiQejD4+hEQR7A+50cxB06mHuZf6O4IX+sg/C+/aC0d1Tz8DzFR05PKQNgkuWNND39/v048drpDXV4PjhGsDuGx3UOPe/pG2QFECBEjfexaLjRcAbaDBE4Rm16Ym2ZK+PLqzcYKzeWffCn4/UvnnwDD47Qm6yeSeM8acWOU3Hi4Cnpxz/6Kkva8+0XsNnR0gmd8KYQ5i5DzoeA4+dc2LmELT4BoRoDvhknE8C4hNlqSYcCkXvhKW0c8ASkMa63xh4gqgSMOquN22xnMdVm7Y0sB8NHMQ9TWfcT/60yr4REOJGB0THQ/Bod3eDbuh1Vt+AEN2PT8b59F27fNoH+2scGzeOeCec3AEJVdlVxC4+6mcn8Bm+anY0xYPw6IsHavEBHgBIv4jF4h89HcgofuMnbfbjR3OQHY5YDsGmJ/ypvC0eRDYP4ovkkH4K2PkjfA7nRASv3tCEl4L+LSktqecgHoId6w+f3FtbPq3ArRNipx3U0GuvY/p+nQIDr9mfypuGgPjscz4SOQ/pKZPi5eBn2H9CbLzjfxNywIeLsvGUnbLyBdtlGDvfdjDsM0Z4Su7/ts8ys/k66z4AAAAASUVORK5CYII=) !important;
  }
  .signature-pad-passive, .signature-placeholder:after {
    background-image: url(data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTk4IiBoZWlnaHQ9IjQwIiB2aWV3Qm94PSIwIDAgMTk4IDQwIiBmaWxsPSJub25lIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgo8cGF0aCBkPSJNNzQuMTA0NCA2LjM0NTA4SDc1LjU4NTlDNzUuNTQxMiA0LjcxNDQgNzQuMDk5NCAzLjUzMTE2IDcyLjAzMTIgMy41MzExNkM2OS45ODc5IDMuNTMxMTYgNjguNDIxOSA0LjY5OTQ4IDY4LjQyMTkgNi40NTQ0NkM2OC40MjE5IDcuODcxMzYgNjkuNDM2MSA4LjcwMTYyIDcxLjA3MTcgOS4xNDQwOUw3Mi4yNzQ5IDkuNDcyMjFDNzMuMzYzNiA5Ljc2MDU2IDc0LjIwMzggMTAuMTE4NSA3NC4yMDM4IDExLjAyMzNDNzQuMjAzOCAxMi4wMTc3IDczLjI1NDMgMTIuNjczOSA3MS45NDY3IDEyLjY3MzlDNzAuNzYzNSAxMi42NzM5IDY5Ljc3OTEgMTIuMTQ2OSA2OS42ODk2IDExLjAzODNINjguMTQ4NEM2OC4yNDc5IDEyLjg4MjcgNjkuNjc0NyAxNC4wMjEyIDcxLjk1NjcgMTQuMDIxMkM3NC4zNDggMTQuMDIxMiA3NS43MjUxIDEyLjc2MzQgNzUuNzI1MSAxMS4wMzgzQzc1LjcyNTEgOS4yMDM3NSA3NC4wODk1IDguNDkyODEgNzIuNzk2OSA4LjE3NDYzTDcxLjgwMjYgNy45MTYxQzcxLjAwNzEgNy43MTIyNyA2OS45NDgyIDcuMzM5NCA2OS45NTMxIDYuMzY0OTdDNjkuOTUzMSA1LjQ5OTkxIDcwLjc0MzYgNC44NTg1OCA3MS45OTY0IDQuODU4NThDNzMuMTY0OCA0Ljg1ODU4IDczLjk5NSA1LjQwNTQ1IDc0LjEwNDQgNi4zNDUwOFoiIGZpbGw9IiM1Qjk1RTYiLz4KPHBhdGggZD0iTTc3LjQ0MTYgMTMuODUyMkg3OC45MjgxVjYuMjE1ODJINzcuNDQxNlYxMy44NTIyWk03OC4xOTIzIDUuMDM3NTVDNzguNzA0NCA1LjAzNzU1IDc5LjEzMTkgNC42Mzk4MyA3OS4xMzE5IDQuMTUyNjFDNzkuMTMxOSAzLjY2NTM5IDc4LjcwNDQgMy4yNjI3IDc4LjE5MjMgMy4yNjI3Qzc3LjY3NTIgMy4yNjI3IDc3LjI1MjcgMy42NjUzOSA3Ny4yNTI3IDQuMTUyNjFDNzcuMjUyNyA0LjYzOTgzIDc3LjY3NTIgNS4wMzc1NSA3OC4xOTIzIDUuMDM3NTVaIiBmaWxsPSIjNUI5NUU2Ii8+CjxwYXRoIGQ9Ik04NC4xMjk2IDE2Ljg2Qzg2LjA3MzUgMTYuODYgODcuNTc0OSAxNS45NzAxIDg3LjU3NDkgMTQuMDIxMlY2LjIxNTgySDg2LjExODNWNy40NTM3NUg4Ni4wMDg5Qzg1Ljc0NTQgNi45ODE0NSA4NS4yMTg0IDYuMTE2MzkgODMuNzk2NSA2LjExNjM5QzgxLjk1MjEgNi4xMTYzOSA4MC41OTQ4IDcuNTczMDYgODAuNTk0OCAxMC4wMDQyQzgwLjU5NDggMTIuNDQwMyA4MS45ODE5IDEzLjczNzggODMuNzg2NiAxMy43Mzc4Qzg1LjE4ODYgMTMuNzM3OCA4NS43MzA1IDEyLjk0NzQgODUuOTk4OSAxMi40NjAxSDg2LjA5MzRWMTMuOTYxNkM4Ni4wOTM0IDE1LjEzOTggODUuMjczMSAxNS42NjE4IDg0LjE0NDUgMTUuNjYxOEM4Mi45MDY2IDE1LjY2MTggODIuNDI0NCAxNS4wNDA0IDgyLjE2MDkgMTQuNjE3OEw4MC44ODMyIDE1LjE0NDhDODEuMjg1OSAxNi4wNjQ1IDgyLjMwNSAxNi44NiA4NC4xMjk2IDE2Ljg2Wk04NC4xMTQ3IDEyLjUwNDlDODIuNzg3MyAxMi41MDQ5IDgyLjA5NjIgMTEuNDg1NyA4Mi4wOTYyIDkuOTg0MjlDODIuMDk2MiA4LjUxNzY3IDgyLjc3MjQgNy4zNzkxNyA4NC4xMTQ3IDcuMzc5MTdDODUuNDEyMyA3LjM3OTE3IDg2LjEwODMgOC40MzgxMiA4Ni4xMDgzIDkuOTg0MjlDODYuMTA4MyAxMS41NjAzIDg1LjM5NzQgMTIuNTA0OSA4NC4xMTQ3IDEyLjUwNDlaIiBmaWxsPSIjNUI5NUU2Ii8+CjxwYXRoIGQ9Ik05MS4wNTUgOS4zMTgwOUM5MS4wNTUgOC4xMDAwNSA5MS44MDA4IDcuNDA0MDMgOTIuODM0OSA3LjQwNDAzQzkzLjg0NDEgNy40MDQwMyA5NC40NTU2IDguMDY1MjUgOTQuNDU1NiA5LjE3MzkyVjEzLjg1MjJIOTUuOTQyMVY4Ljk5NDk0Qzk1Ljk0MjEgNy4xMDU3NCA5NC45MDMxIDYuMTE2MzkgOTMuMzQyIDYuMTE2MzlDOTIuMTkzNSA2LjExNjM5IDkxLjQ0MjggNi42NDgzNSA5MS4wODk4IDcuNDU4NzJIOTAuOTk1NFY2LjIxNTgySDg5LjU2ODVWMTMuODUyMkg5MS4wNTVWOS4zMTgwOVoiIGZpbGw9IiM1Qjk1RTYiLz4KPHBhdGggZD0iTTEwMS43NiAxMy44NTIySDEwMy4yOTZWOS40MTI1NUgxMDguMzcyVjEzLjg1MjJIMTA5LjkxNFYzLjY3MDM3SDEwOC4zNzJWOC4wOTUwOEgxMDMuMjk2VjMuNjcwMzdIMTAxLjc2VjEzLjg1MjJaIiBmaWxsPSIjNUI5NUU2Ii8+CjxwYXRoIGQ9Ik0xMTUuMzIzIDE0LjAwNjNDMTE2Ljk4OCAxNC4wMDYzIDExOC4xNjYgMTMuMTg2IDExOC41MDQgMTEuOTQzMUwxMTcuMDk3IDExLjY4OTVDMTE2LjgyOSAxMi40MTA0IDExNi4xODMgMTIuNzc4MyAxMTUuMzM4IDEyLjc3ODNDMTE0LjA2NSAxMi43NzgzIDExMy4yMSAxMS45NTMgMTEzLjE3IDEwLjQ4MTRIMTE4LjU5OVY5Ljk1NDQ2QzExOC41OTkgNy4xOTUyMiAxMTYuOTQ4IDYuMTE2MzkgMTE1LjIxOCA2LjExNjM5QzExMy4wOSA2LjExNjM5IDExMS42ODggNy43MzcxMyAxMTEuNjg4IDEwLjA4MzdDMTExLjY4OCAxMi40NTUyIDExMy4wNyAxNC4wMDYzIDExNS4zMjMgMTQuMDA2M1pNMTEzLjE3NSA5LjM2NzgxQzExMy4yMzUgOC4yODQgMTE0LjAyIDcuMzQ0MzcgMTE1LjIyOCA3LjM0NDM3QzExNi4zODIgNy4zNDQzNyAxMTcuMTM3IDguMTk5NDkgMTE3LjE0MiA5LjM2NzgxSDExMy4xNzVaIiBmaWxsPSIjNUI5NUU2Ii8+CjxwYXRoIGQ9Ik0xMjAuMjQ4IDEzLjg1MjJIMTIxLjczNVY5LjE4ODgzQzEyMS43MzUgOC4xODk1NCAxMjIuNTA1IDcuNDY4NjYgMTIzLjU1OSA3LjQ2ODY2QzEyMy44NjggNy40Njg2NiAxMjQuMjE2IDcuNTIzMzUgMTI0LjMzNSA3LjU1ODE1VjYuMTM2MjdDMTI0LjE4NiA2LjExNjM5IDEyMy44OTIgNi4xMDE0NyAxMjMuNzAzIDYuMTAxNDdDMTIyLjgwOSA2LjEwMTQ3IDEyMi4wNDMgNi42MDg1OCAxMjEuNzY1IDcuNDI4ODlIMTIxLjY4NVY2LjIxNTgySDEyMC4yNDhWMTMuODUyMloiIGZpbGw9IiM1Qjk1RTYiLz4KPHBhdGggZD0iTTEyOC42MzkgMTQuMDA2M0MxMzAuMzA1IDE0LjAwNjMgMTMxLjQ4MyAxMy4xODYgMTMxLjgyMSAxMS45NDMxTDEzMC40MTQgMTEuNjg5NUMxMzAuMTQ1IDEyLjQxMDQgMTI5LjQ5OSAxMi43NzgzIDEyOC42NTQgMTIuNzc4M0MxMjcuMzgxIDEyLjc3ODMgMTI2LjUyNiAxMS45NTMgMTI2LjQ4NiAxMC40ODE0SDEzMS45MTVWOS45NTQ0NkMxMzEuOTE1IDcuMTk1MjIgMTMwLjI2NSA2LjExNjM5IDEyOC41MzUgNi4xMTYzOUMxMjYuNDA3IDYuMTE2MzkgMTI1LjAwNSA3LjczNzEzIDEyNS4wMDUgMTAuMDgzN0MxMjUuMDA1IDEyLjQ1NTIgMTI2LjM4NyAxNC4wMDYzIDEyOC42MzkgMTQuMDA2M1pNMTI2LjQ5MSA5LjM2NzgxQzEyNi41NTEgOC4yODQgMTI3LjMzNiA3LjM0NDM3IDEyOC41NDUgNy4zNDQzN0MxMjkuNjk4IDcuMzQ0MzcgMTMwLjQ1NCA4LjE5OTQ5IDEzMC40NTkgOS4zNjc4MUgxMjYuNDkxWiIgZmlsbD0iIzVCOTVFNiIvPgo8cGF0aCBkPSJNMSAzNi4wMjI5QzEyLjI0NjEgMzkuMjIwNSAyMy4xODIgMzUuMDMyOCAzMi41MDg0IDI4Ljg1MTFDMzcuNDQwNCAyNS41ODIyIDQyLjMzNDEgMjEuNjY4NyA0NS4zMzI5IDE2LjUxMDFDNDYuNTI4MyAxNC40NTM5IDQ3Ljk4OTMgMTAuODg0NCA0NC4yMjcxIDEwLjg1MjhDNDAuMTMzNyAxMC44MTgzIDM3LjA4NjQgMTQuNTE0MiAzNS41NTg4IDE3Ljg3NDRDMzMuMzY4MSAyMi42OTMzIDMzLjI5MSAyOC40MDA0IDM1Ljk2NTYgMzMuMDQ0MUMzOC40OTcxIDM3LjQzOTYgNDIuNzQ0NSAzOS41MTg0IDQ3LjgxMTQgMzguNjYzOUM1My4xMDM3IDM3Ljc3MTMgNTcuNzMwNCAzNC4xNTYyIDYxLjU3NjUgMzAuNjc4NUM2Mi45OTMgMjkuMzk3NiA2NC4zMjA5IDI4LjA0NzUgNjUuNTQyIDI2LjU4NTdDNjUuNjg0MiAyNi40MTU1IDY2LjE4NDIgMjUuNTc5OCA2Ni41MDggMjUuNTIxOEM2Ni42Mjg0IDI1LjUwMDIgNjYuODA2NCAyOS4xNjQ1IDY2LjgzODUgMjkuMzY0M0M2Ny4xMjU1IDMxLjE1NDMgNjguMDI5NCAzMy4xNzA2IDcwLjE0MzEgMzMuMjMxOEM3Mi44MzMyIDMzLjMwOTcgNzUuMDgyNiAzMS4wNTkxIDc2Ljg5MjIgMjkuNDAxOEM3Ny41MDI2IDI4Ljg0MjggNzkuNDQyNSAyNi4xNjAxIDgwLjQ3NjQgMjYuMTYwMUM4MC45MDE0IDI2LjE2MDEgODEuNzI0OSAyOC4zMDM4IDgxLjkxMjcgMjguNTg4M0M4NC4zOTcyIDMyLjM1MjMgODguMDQ0NiAzMC45ODk0IDkwLjg3MzMgMjguMzUwNUM5MS4zOTM0IDI3Ljg2NTMgOTQuMTc4MSAyMy45ODM5IDk1LjMwOTEgMjQuNjgzMkM5Ni4yMjAzIDI1LjI0NjYgOTYuNjIxNyAyNi41NzY1IDk3LjA4ODYgMjcuNDYxOEM5Ny44NDg0IDI4LjkwMjkgOTguODEwNyAyOS45Mjk0IDEwMC40MTkgMzAuNDY1N0MxMDMuOTEyIDMxLjYzMSAxMDcuNjggMjguMzYzIDExMS4yMjIgMjguMzYzQzExMi4yNTUgMjguMzYzIDExMi43ODMgMjguOTMxNiAxMTMuMzMyIDI5LjcxNDhDMTE0LjA4MSAzMC43ODIzIDExNC44NTMgMzEuNTI3NiAxMTYuMjA1IDMxLjgxNzVDMTIwLjM5MyAzMi43MTU1IDEyMy44MjIgMjguNzM5OSAxMjcuODcyIDI5LjA4ODlDMTI5LjA1MyAyOS4xOTA3IDEyOS45MzUgMzAuMzgxNiAxMzAuODIxIDMxLjAxNjRDMTMyLjYwOSAzMi4yOTY5IDEzNC43NTkgMzMuMTgzNiAxMzYuOTQ4IDMzLjQ5NDdDMTQwLjQ1NyAzMy45OTM0IDE0My45NzUgMzMuMzMyNiAxNDcuMzk1IDMyLjU5MzVDMTUzLjMgMzEuMzE3NCAxNTkuMTQ3IDI5Ljc5NTggMTY1LjA2MiAyOC41NjMzIiBzdHJva2U9IiM1Qjk1RTYiIHN0cm9rZS13aWR0aD0iMS41IiBzdHJva2UtbGluZWNhcD0icm91bmQiIHN0cm9rZS1saW5lam9pbj0icm91bmQiLz4KPHBhdGggZD0iTTE5Ni41MTUgMTUuMDc3OEwxODQuNDkyIDAuNTUxNzk1QzE4NC4yNTcgMC4yNjc4MSAxODMuODM4IDAuMjI4MjYgMTgzLjU1NCAwLjQ2MzMwN0wxODAuNjQ5IDIuODY3ODhDMTgwLjM2NSAzLjEwMjkzIDE4MC4zMjUgMy41MjI0IDE4MC41NiAzLjgwNjM4TDE5Mi41ODMgMTguMzMyNEMxOTIuNyAxOC40NzQxIDE5Mi44NjQgMTguNTU1MSAxOTMuMDM0IDE4LjU3MTJDMTkzLjIwNCAxOC41ODcyIDE5My4zOCAxOC41MzgyIDE5My41MjIgMTguNDIwOUwxOTYuNDI3IDE2LjAxNjRDMTk2LjcxMSAxNS43ODEzIDE5Ni43NSAxNS4zNjE4IDE5Ni41MTUgMTUuMDc3OFoiIGZpbGw9IiM1Qjk1RTYiLz4KPHBhdGggZD0iTTE4MS40MzYgNi45NTcyTDE3MC44NTUgOS44MjU5M0MxNzAuNjIyIDkuODg5MDEgMTcwLjQ0MSAxMC4wNzI5IDE3MC4zODMgMTAuMzA3MUwxNjYuMTU1IDI3LjEwMTdMMTczLjk3NSAyMC42MjkxQzE3My4yNDUgMTkuMjYxMiAxNzMuNTUgMTcuNTE4OSAxNzQuNzkgMTYuNDkyMUMxNzYuMjA2IDE1LjMxOTggMTc4LjMxMiAxNS41MTkxIDE3OS40ODMgMTYuOTM0NkMxODAuNjU1IDE4LjM1MDggMTgwLjQ1NiAyMC40NTYxIDE3OS4wNDEgMjEuNjI3OEMxNzguMzMzIDIyLjIxMzkgMTc3LjQ1MiAyMi40NTc3IDE3Ni42MDMgMjIuMzc3NkMxNzUuOTY0IDIyLjMxNzQgMTc1LjM0MyAyMi4wNzQgMTc0LjgyNSAyMS42NTY4TDE2Ny4wMDUgMjguMTI4NkwxODQuMjk0IDI3LjExMzdDMTg0LjUzNCAyNy4wOTk2IDE4NC43NDkgMjYuOTU3MSAxODQuODU0IDI2Ljc0MDFMMTg5LjY1IDE2Ljg4MTRMMTgxLjQzNiA2Ljk1NzJaIiBmaWxsPSIjNUI5NUU2Ii8+Cjwvc3ZnPgo=);
  }
  .form-spinner-button.form-spinner-up:before {
    background-image: url(data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTQiIGhlaWdodD0iMTQiIHZpZXdCb3g9IjAgMCAxNCAxNCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPHBhdGggZmlsbC1ydWxlPSJldmVub2RkIiBjbGlwLXJ1bGU9ImV2ZW5vZGQiIGQ9Ik03LjUgMTIuNDAwNEw3LjUgNy40MDAzOUwxMi41IDcuNDAwMzlDMTIuNzc2IDcuNDAwMzkgMTMgNy4xNzYzOSAxMyA2LjkwMDM5QzEzIDYuNjI0MzkgMTIuNzc2IDYuNDAwMzkgMTIuNSA2LjQwMDM5TDcuNSA2LjQwMDM5TDcuNSAxLjQwMDM5QzcuNSAxLjEyNDM5IDcuMjc2IDAuOTAwMzkgNyAwLjkwMDM5QzYuNzI0IDAuOTAwMzkgNi41IDEuMTI0MzkgNi41IDEuNDAwMzlMNi41IDYuNDAwMzlMMS41IDYuNDAwMzlDMS4yMjQgNi40MDAzOSAxIDYuNjI0MzkgMSA2LjkwMDM5QzEgNy4xNzYzOSAxLjIyNCA3LjQwMDM5IDEuNSA3LjQwMDM5TDYuNSA3LjQwMDM5TDYuNSAxMi40MDA0QzYuNSAxMi42NzY0IDYuNzI0IDEyLjkwMDQgNyAxMi45MDA0QzcuMjc2IDEyLjkwMDQgNy41IDEyLjY3NjQgNy41IDEyLjQwMDRaIiBmaWxsPSJ3aGl0ZSIgc3Ryb2tlPSJ3aGl0ZSIgc3Ryb2tlLXdpZHRoPSIwLjUiLz4KPC9zdmc+Cg==);
  }
  .form-spinner-button.form-spinner-down:before {
    background-image: url(data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTQiIGhlaWdodD0iMiIgdmlld0JveD0iMCAwIDE0IDIiIGZpbGw9Im5vbmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+CjxwYXRoIGQ9Ik0xMi41IDEuNDAwMzlMNy41IDEuNDAwMzlMMS41IDEuNDAwMzlDMS4yMjQgMS40MDAzOSAxIDEuMTc2MzkgMSAwLjkwMDM5QzEgMC42MjQzOSAxLjIyNCAwLjQwMDM5IDEuNSAwLjQwMDM5TDYuNSAwLjQwMDM5TDEyLjUgMC40MDAzOTFDMTIuNzc2IDAuNDAwMzkxIDEzIDAuNjI0MzkxIDEzIDAuOTAwMzkxQzEzIDEuMTc2MzkgMTIuNzc2IDEuNDAwMzkgMTIuNSAxLjQwMDM5WiIgZmlsbD0id2hpdGUiIHN0cm9rZT0id2hpdGUiIHN0cm9rZS13aWR0aD0iMC41Ii8+Cjwvc3ZnPgo=);
  }
  .form-collapse-table:after{
    background-image: url(data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjgiIGhlaWdodD0iMjgiIHZpZXdCb3g9IjAgMCAyOCAyOCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPHBhdGggZmlsbC1ydWxlPSJldmVub2RkIiBjbGlwLXJ1bGU9ImV2ZW5vZGQiIGQ9Ik0yOCAxNEMyOCA2LjI2ODAxIDIxLjczMiAtOS40OTkzNWUtMDcgMTQgLTYuMTE5NTllLTA3QzYuMjY4MDEgLTIuNzM5ODRlLTA3IC05LjQ5OTM1ZS0wNyA2LjI2ODAxIC02LjExOTU5ZS0wNyAxNEMtMi43Mzk4NGUtMDcgMjEuNzMyIDYuMjY4MDEgMjggMTQgMjhDMjEuNzMyIDI4IDI4IDIxLjczMiAyOCAxNFpNOC4wMDI0IDExLjcwMDNDNy45OTI0NCAxMS41ODEzIDguMDEzNjMgMTEuNDYxNyA4LjA2MzU5IDExLjM1NDlDOC4xMTM0NyAxMS4yNDgyIDguMTkwMDUgMTEuMTU4NSA4LjI4NDc5IDExLjA5NTlDOC4zNzk1MiAxMS4wMzMyIDguNDg4NjUgMTEgOC41OTk5OSAxMUwxOS40IDExQzE5LjUxMTMgMTEgMTkuNjIwNSAxMS4wMzMyIDE5LjcxNTIgMTEuMDk1OUMxOS44MDk5IDExLjE1ODUgMTkuODg2NSAxMS4yNDgyIDE5LjkzNjQgMTEuMzU0OUMxOS45Nzc5IDExLjQ0NDQgMTkuOTk5NiAxMS41NDI5IDIwIDExLjY0MjlDMjAgMTEuNzgyIDE5Ljk1NzkgMTEuOTE3MyAxOS44OCAxMi4wMjg2TDE0LjQ4IDE5Ljc0MjlDMTQuNDI0MSAxOS44MjI3IDE0LjM1MTYgMTkuODg3NSAxNC4yNjgzIDE5LjkzMjFDMTQuMTg1IDE5Ljk3NjggMTQuMDkzMSAyMCAxNCAyMEMxMy45MDY4IDIwIDEzLjgxNSAxOS45NzY4IDEzLjczMTcgMTkuOTMyMUMxMy42NDg0IDE5Ljg4NzUgMTMuNTc1OSAxOS44MjI3IDEzLjUyIDE5Ljc0MjlMOC4xMTk5OSAxMi4wMjg2QzguMDUzMDggMTEuOTMzIDguMDEyMzYgMTEuODE5MyA4LjAwMjQgMTEuNzAwM1oiIGZpbGw9IndoaXRlIi8+Cjwvc3ZnPgo=);
  }
  li[data-type=control_fileupload] .qq-upload-button:before {
    background-image: url(data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMzkiIGhlaWdodD0iMjgiIHZpZXdCb3g9IjAgMCAzOSAyOCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPHBhdGggZD0iTTMyLjM3NSAxMi4xODc1QzMxLjUgNS42ODc1IDI2IDAuODc1IDE5LjM3NSAwLjg3NUMxMy42ODc1IDAuODc1IDguNzUgNC40Mzc1IDYuOTM3NSA5LjgxMjVDMi44NzUgMTAuNjg3NSAwIDE0LjE4NzUgMCAxOC4zNzVDMCAyMi45Mzc1IDMuNTYyNSAyNi43NSA4LjEyNSAyNy4xMjVIMzEuODc1SDMxLjkzNzVDMzUuNzUgMjYuNzUgMzguNzUgMjMuNSAzOC43NSAxOS42MjVDMzguNzUgMTUuOTM3NSAzNiAxMi43NSAzMi4zNzUgMTIuMTg3NVpNMjYuMDYyNSAxNS42ODc1QzI1LjkzNzUgMTUuODEyNSAyNS44MTI1IDE1Ljg3NSAyNS42MjUgMTUuODc1QzI1LjQzNzUgMTUuODc1IDI1LjMxMjUgMTUuODEyNSAyNS4xODc1IDE1LjY4NzVMMjAgMTAuNVYyMi43NUMyMCAyMy4xMjUgMTkuNzUgMjMuMzc1IDE5LjM3NSAyMy4zNzVDMTkgMjMuMzc1IDE4Ljc1IDIzLjEyNSAxOC43NSAyMi43NVYxMC41TDEzLjU2MjUgMTUuNjg3NUMxMy4zMTI1IDE1LjkzNzUgMTIuOTM3NSAxNS45Mzc1IDEyLjY4NzUgMTUuNjg3NUMxMi40Mzc1IDE1LjQzNzUgMTIuNDM3NSAxNS4wNjI1IDEyLjY4NzUgMTQuODEyNUwxOC45Mzc1IDguNTYyNUMxOSA4LjUgMTkuMDYyNSA4LjQzNzUgMTkuMTI1IDguNDM3NUMxOS4yNSA4LjM3NSAxOS40Mzc1IDguMzc1IDE5LjYyNSA4LjQzNzVDMTkuNjg3NSA4LjUgMTkuNzUgOC41IDE5LjgxMjUgOC41NjI1TDI2LjA2MjUgMTQuODEyNUMyNi4zMTI1IDE1LjA2MjUgMjYuMzEyNSAxNS40Mzc1IDI2LjA2MjUgMTUuNjg3NVoiIGZpbGw9IiM1Qjk1RTYiLz4KPC9zdmc+Cg==);
  }
  .appointmentDayPickerButton {
    background-image: url(data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNiIgaGVpZ2h0PSIxMCIgdmlld0JveD0iMCAwIDYgMTAiIGZpbGw9Im5vbmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+CjxwYXRoIGQ9Ik0xIDlMNSA1TDEgMSIgc3Ryb2tlPSIjMTI0NThEIiBzdHJva2Utd2lkdGg9IjIiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgc3Ryb2tlLWxpbmVqb2luPSJyb3VuZCIvPgo8L3N2Zz4K);
  }

  /* NEW THEME STYLE */
  /*PREFERENCES STYLE*//*PREFERENCES STYLE*/
    .form-all {
      font-family: Inter, sans-serif;
    }
    .form-all .qq-upload-button,
    .form-all .form-submit-button,
    .form-all .form-submit-reset,
    .form-all .form-submit-print {
      font-family: Inter, sans-serif;
    }
    .form-all .form-pagebreak-back-container,
    .form-all .form-pagebreak-next-container {
      font-family: Inter, sans-serif;
    }
    .form-header-group {
      font-family: Inter, sans-serif;
    }
    .form-label {
      font-family: Inter, sans-serif;
    }
  
    .form-label.form-label-auto {
      
    display: block;
    float: none;
    text-align: left;
    width: 100%;
  
    }
  
    .form-line {
      margin-top: 12px;
      margin-bottom: 12px;
    }
  
    .form-all {
      max-width: 1000px;
      width: 100%;
    }
  
    .form-label.form-label-left,
    .form-label.form-label-right,
    .form-label.form-label-left.form-label-auto,
    .form-label.form-label-right.form-label-auto {
      width: 230px;
    }
  
    .form-all {
      font-size: 16px
    }
    .form-all .qq-upload-button,
    .form-all .qq-upload-button,
    .form-all .form-submit-button,
    .form-all .form-submit-reset,
    .form-all .form-submit-print {
      font-size: 16px
    }
    .form-all .form-pagebreak-back-container,
    .form-all .form-pagebreak-next-container {
      font-size: 16px
    }
  
    .supernova .form-all, .form-all {
      background-color: #E4EFFF;
    }
  
    .form-all {
      color: #000000;
    }
    .form-header-group .form-header {
      color: #000000;
    }
    .form-header-group .form-subHeader {
      color: #000000;
    }
    .form-label-top,
    .form-label-left,
    .form-label-right,
    .form-html,
    .form-checkbox-item label,
    .form-radio-item label {
      color: #000000;
    }
    .form-sub-label {
      color: #1a1a1a;
    }
  
    .supernova {
      background-color: #2462B9;
     
    }
    .supernova body {
      background: transparent;
    }
  
    .form-textbox,
    .form-textarea,
    .form-dropdown,
    .form-radio-other-input,
    .form-checkbox-other-input,
    .form-captcha input,
    .form-spinner input {
      background-color: #FFFFFF;
    }
  
    .supernova {
      background-image: none;
    }
    #stage {
      background-image: none;
    }
  
    .form-all {
      background-image: none;
    }
  
    .form-all {
      position: relative;
    }
    .form-all:before {
      content: "";
      background-image: url("https://www.jotform.com/uploads/coxwm11/form_files/MSCS-Logo-Reverse-White-Transparent-Bkg.6261c3ef83c075.25845520.png");
      display: inline-block;
      height: 144.24242424242425px;
      position: absolute;
      background-size: 170px 144px;
      background-repeat: no-repeat;
      width: 100%;
    }
    .form-all {
      margin-top: 164px !important;
    }
    .form-all:before {
      top: -154px;
      background-position: top center;
      left: 0;
    }
           
  .ie-8 .form-all:before { display: none; }
  .ie-8 {
    margin-top: auto;
    margin-top: initial;
  }
  
  /*PREFERENCES STYLE*//*__INSPECT_SEPERATOR__*/
    /* Injected CSS Code */
</style>

<script>
    

</script>

<script src="https://cdn01.jotfor.ms/static/prototype.forms.js" type="text/javascript"></script>
<script src="https://cdn02.jotfor.ms/static/jotform.forms.js?3.3.32846" type="text/javascript"></script>
<script type="text/javascript">	JotForm.newDefaultTheme = true;
	JotForm.extendsNewTheme = false;
	JotForm.newPaymentUIForNewCreatedForms = true;
	JotForm.newPaymentUI = true;

   JotForm.setConditions([{"action":[{"id":"action_1650575024748","visibility":"Show","isError":false,"field":"7"}],"id":"1650575046227","index":"0","link":"Any","priority":"0","terms":[{"id":"term_1650575024748","field":"4","operator":"equals","value":"DENIED","isError":false}],"type":"field"}]);	JotForm.clearFieldOnHide="disable";
	JotForm.submitError="jumpToFirstError";

	JotForm.init(function(){
	/*INIT-START*/
if (window.JotForm && JotForm.accessible) $('input_3').setAttribute('tabindex',0);
      JotForm.alterTexts(undefined);
	/*INIT-END*/
	});

   JotForm.prepareCalculationsOnTheFly([null,{"name":"heading","qid":"1","text":"Student Device Request DDA Review","type":"control_head"},{"name":"submit2","qid":"2","text":"Submit","type":"control_button"},{"description":"","name":"studentsPsid","qid":"3","subLabel":"","text":"Student's PSID","type":"control_textbox"},{"description":"","name":"selectThe","qid":"4","text":"Select the Response.","type":"control_radio"},null,null,{"description":"","name":"reasonFor","qid":"7","text":"Reason for Denial.","type":"control_radio"},null,null,{"description":"","name":"searchThe","qid":"10","subLabel":"","text":"Search the Database by School to Review Request. ","type":"control_dropdown"}]);
   setTimeout(function() {
JotForm.paymentExtrasOnTheFly([null,{"name":"heading","qid":"1","text":"Student Device Request DDA Review","type":"control_head"},{"name":"submit2","qid":"2","text":"Submit","type":"control_button"},{"description":"","name":"studentsPsid","qid":"3","subLabel":"","text":"Student's PSID","type":"control_textbox"},{"description":"","name":"selectThe","qid":"4","text":"Select the Response.","type":"control_radio"},null,null,{"description":"","name":"reasonFor","qid":"7","text":"Reason for Denial.","type":"control_radio"},null,null,{"description":"","name":"searchThe","qid":"10","subLabel":"","text":"Search the Database by School to Review Request. ","type":"control_dropdown"}]);}, 20); 
</script>

      <script>
function searchBar() {
  var input, filter, table, tr, td, i, txtValue;
  input = document.getElementById("myInput");
  filter = input.value.toUpperCase();
  table = document.getElementById("myTable");
  tr = table.getElementsByTagName("tr");
  for (i = 0; i < tr.length; i++) {
    td = tr[i].getElementsByTagName("td")[7];
    if (td) {
      txtValue = td.textContent || td.innerText;
      if (txtValue.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    }       
  }
}








</script>

<style>
    .searchBox{
        width:200px;
    }
</style>
</head>
<body>
<form class="jotform-form" action="/DDA Vett Form/Student_Device_Request_DDA_Search.php" method="post" name="form_221106862477053" id="221106862477053" accept-charset="utf-8" autocomplete="on">
  <input type="hidden" name="formID" value="221106862477053" />
  <input type="hidden" id="JWTContainer" value="" />
  <input type="hidden" id="cardinalOrderNumber" value="" />
  <div role="main" class="form-all">
    <div class="formLogoWrapper Center">
      <img loading="lazy" class="formLogoImg" src="https://www.jotform.com/uploads/coxwm11/form_files/MSCS-Logo-Reverse-White-Transparent-Bkg.6261c3ef83c075.25845520.png" height="144" width="170">
    </div>
    <style>
      .formLogoWrapper { display:inline-block; position: absolute; width: 100%;} .form-all:before { background: none !important;} .formLogoWrapper.Center { top: -154px; text-align: center;}
    </style>
    <ul class="form-section page-section">
      <li id="cid_1" class="form-input-wide" data-type="control_head">
        <div class="form-header-group  header-large">
          <div class="header-text httal htvam">
            <h1 id="header_1" class="form-header" data-component="header">
              Student Device Request Search Results
            </h1>
          </div>
        </div>
      </li>
      <li class="form-line" data-type="control_dropdown" id="id_10">
        <label class="form-label form-label-top form-label-auto" id="label_10" for="input_10"> Search the Database by School to Review Request. </label>
        <div id="cid_10" class="form-input-wide" data-layout="half">
          <select class="form-dropdown" id="input_10" name="q8_selectYour8" style="width:310px" data-component="dropdown">
            <option value=""> Please Select </option>
            <option value="A. B. Hill ES "> A. B. Hill ES </option>
            <option value="A. Maceo Walker MS "> A. Maceo Walker MS </option>
            <option value="Adolescent Parenting Program  "> Adolescent Parenting Program </option>
            <option value="Airways Achievement Academy "> Airways Achievement Academy </option>
            <option value="Alcy ES "> Alcy ES </option>
            <option value="Alton ES "> Alton ES </option>
            <option value="American Way MS "> American Way MS </option>
            <option value="Avon Lennox HS "> Avon Lennox HS </option>
            <option value="Balmoral-Ridgeway ES "> Balmoral-Ridgeway ES </option>
            <option value="Barret's Chapel K-8 "> Barret's Chapel K-8 </option>
            <option value="Belle Forest ES "> Belle Forest ES </option>
            <option value="Bellevue MS "> Bellevue MS </option>
            <option value="Berclair ES "> Berclair ES </option>
            <option value="Bethel Grove ES "> Bethel Grove ES </option>
            <option value="Bolton HS "> Bolton HS </option>
            <option value="Booker T. Washington MS "> Booker T. Washington MS </option>
            <option value="Brewster ES "> Brewster ES </option>
            <option value="Brownsville Road ES "> Brownsville Road ES </option>
            <option value="Bruce ES"> Bruce ES </option>
            <option value="Central HS "> Central HS </option>
            <option value="Cherokee ES "> Cherokee ES </option>
            <option value="Chickasaw MS "> Chickasaw MS </option>
            <option value="Chimneyrock ES "> Chimneyrock ES </option>
            <option value="Colonial MS "> Colonial MS </option>
            <option value="Cordova ES "> Cordova ES </option>
            <option value="Cordova HS "> Cordova HS </option>
            <option value="Cordova MS "> Cordova MS </option>
            <option value="Craigmont HS "> Craigmont HS </option>
            <option value="Craigmont MS "> Craigmont MS </option>
            <option value="Cromwell ES "> Cromwell ES </option>
            <option value="Crump ES "> Crump ES </option>
            <option value="Cummings K-8 "> Cummings K-8 </option>
            <option value="Delano ES "> Delano ES </option>
            <option value="Dexter ES "> Dexter ES </option>
            <option value="Dexter MS "> Dexter MS </option>
            <option value="Double Tree ES "> Double Tree ES </option>
            <option value="Douglass HS "> Douglass HS </option>
            <option value="Douglass K-8 "> Douglass K-8 </option>
            <option value="Downtown ES "> Downtown ES </option>
            <option value="Dunbar ES "> Dunbar ES </option>
            <option value="East High STEM  "> East High STEM </option>
            <option value="EE Jeter K-8 "> EE Jeter K-8 </option>
            <option value="Egypt ES "> Egypt ES </option>
            <option value="Evans ES "> Evans ES </option>
            <option value="Ford Road ES "> Ford Road ES </option>
            <option value="Fox Meadows ES "> Fox Meadows ES </option>
            <option value="G.W. Carver Career Academy "> G.W. Carver Career Academy </option>
            <option value="Gardenview ES "> Gardenview ES </option>
            <option value="Geeter K-8 "> Geeter K-8 </option>
            <option value="Georgian Hills MS "> Georgian Hills MS </option>
            <option value="Germanshire ES "> Germanshire ES </option>
            <option value="Germantown ES "> Germantown ES </option>
            <option value="Germantown HS "> Germantown HS </option>
            <option value="Germantown MS "> Germantown MS </option>
            <option value="Getwell ES "> Getwell ES </option>
            <option value="Gordon Achievement Academy "> Gordon Achievement Academy </option>
            <option value="Grahamwood ES "> Grahamwood ES </option>
            <option value="Grandview Heights MS "> Grandview Heights MS </option>
            <option value="Hamilton HS "> Hamilton HS </option>
            <option value="Hamilton K-8 "> Hamilton K-8 </option>
            <option value="Havenivew MS "> Havenivew MS </option>
            <option value="Hawkins Mill ES "> Hawkins Mill ES </option>
            <option value="Hickory Ridge ES "> Hickory Ridge ES </option>
            <option value="Hickory Ridge MS "> Hickory Ridge MS </option>
            <option value="Highland Oaks ES "> Highland Oaks ES </option>
            <option value="Highland Oaks MS "> Highland Oaks MS </option>
            <option value="Hollis F. Price HS "> Hollis F. Price HS </option>
            <option value="Holmes Road ES "> Holmes Road ES </option>
            <option value="Hope Academy"> Hope Academy </option>
            <option value="Ida B. Wells Academy "> Ida B. Wells Academy </option>
            <option value="Idlewild ES "> Idlewild ES </option>
            <option value="J.P. Freeman K-8 "> J.P. Freeman K-8 </option>
            <option value="Jackson ES "> Jackson ES </option>
            <option value="Kate Bond ES "> Kate Bond ES </option>
            <option value="Kate Bond MS "> Kate Bond MS </option>
            <option value="Keystone ES "> Keystone ES </option>
            <option value="Kingsbury ES "> Kingsbury ES </option>
            <option value="Kingsbury HS "> Kingsbury HS </option>
            <option value="Kingsbury MS "> Kingsbury MS </option>
            <option value="Kirby HS "> Kirby HS </option>
            <option value="LaRose ES "> LaRose ES </option>
            <option value="Levi ES  "> Levi ES </option>
            <option value="Lowrance K-8 "> Lowrance K-8 </option>
            <option value="Lucie E. Campbell ES "> Lucie E. Campbell ES </option>
            <option value="Lucy ES "> Lucy ES </option>
            <option value="Macon Hall ES "> Macon Hall ES </option>
            <option value="Manassas HS "> Manassas HS </option>
            <option value="Maxine Smith MS "> Maxine Smith MS </option>
            <option value="Medical District High School"> Medical District High School </option>
            <option value="Melrose HS "> Melrose HS </option>
            <option value="Memphis Virtual School"> Memphis Virtual School </option>
            <option value="Middle College HS "> Middle College HS </option>
            <option value="Mitchell HS "> Mitchell HS </option>
            <option value="Mt. Pisgah MS "> Mt. Pisgah MS </option>
            <option value="New Comers International Ctr "> New Comers International Ctr </option>
            <option value="Newberry ES "> Newberry ES </option>
            <option value="Northaven ES "> Northaven ES </option>
            <option value="Northeast Prep Academy "> Northeast Prep Academy </option>
            <option value="Northwest Prep Academy  "> Northwest Prep Academy </option>
            <option value="Oak Forest ES "> Oak Forest ES </option>
            <option value="Oakhaven ES "> Oakhaven ES </option>
            <option value="Oakhaven HS "> Oakhaven HS </option>
            <option value="Oakhaven MS "> Oakhaven MS </option>
            <option value="Oakshire ES "> Oakshire ES </option>
            <option value="Overton HS "> Overton HS </option>
            <option value="Parkway Village ES "> Parkway Village ES </option>
            <option value="Peabody ES "> Peabody ES </option>
            <option value="Raleigh Bartlett Meadows ES "> Raleigh Bartlett Meadows ES </option>
            <option value="Raleigh Egypt HS "> Raleigh Egypt HS </option>
            <option value="Raleigh Egypt MS "> Raleigh Egypt MS </option>
            <option value="Richland ES "> Richland ES </option>
            <option value="Ridgeway HS "> Ridgeway HS </option>
            <option value="Ridgeway MS "> Ridgeway MS </option>
            <option value="Riverview K-8 "> Riverview K-8 </option>
            <option value="Riverwood ES "> Riverwood ES </option>
            <option value="Robert R. Church ES "> Robert R. Church ES </option>
            <option value="Ross ES "> Ross ES </option>
            <option value="Rozelle ES "> Rozelle ES </option>
            <option value="Scenic Hills ES "> Scenic Hills ES </option>
            <option value="Sea Isle ES "> Sea Isle ES </option>
            <option value="Shady Grove ES "> Shady Grove ES </option>
            <option value="Sharpe ES "> Sharpe ES </option>
            <option value="Sheffield ES "> Sheffield ES </option>
            <option value="Sheffield HS "> Sheffield HS </option>
            <option value="Shelby Oaks ES "> Shelby Oaks ES </option>
            <option value="Sherwood ES "> Sherwood ES </option>
            <option value="Sherwood MS "> Sherwood MS </option>
            <option value="Shrine School "> Shrine School </option>
            <option value="Snowden K-8 "> Snowden K-8 </option>
            <option value="South Park ES "> South Park ES </option>
            <option value="Southwind ES "> Southwind ES </option>
            <option value="Southwind HS "> Southwind HS </option>
            <option value="Springdale ES "> Springdale ES </option>
            <option value="Treadwell ES "> Treadwell ES </option>
            <option value="Treadwell MS "> Treadwell MS </option>
            <option value="Trezevant HS "> Trezevant HS </option>
            <option value="Vollentine ES "> Vollentine ES </option>
            <option value="Wells Station ES "> Wells Station ES </option>
            <option value="Westhaven ES "> Westhaven ES </option>
            <option value="Westside ES "> Westside ES </option>
            <option value="Westwood HS "> Westwood HS </option>
            <option value="White Station ES "> White Station ES </option>
            <option value="White Station HS "> White Station HS </option>
            <option value="White Station MS "> White Station MS </option>
            <option value="Whitehaven ES "> Whitehaven ES </option>
            <option value="Whitehaven HS "> Whitehaven HS </option>
            <option value="Willow Oaks ES "> Willow Oaks ES </option>
            <option value="Winchester ES "> Winchester ES </option>
            <option value="Winridge ES "> Winridge ES </option>
            <option value="Wooddale HS "> Wooddale HS </option>
            <option value="Woodstock MS "> Woodstock MS </option>
          </select>
        </div>
      </li>


     
      
      <li class="form-line" data-type="control_button" id="id_2">
        <div id="cid_2" class="form-input-wide" data-layout="full">
          <div data-align="auto" class="form-buttons-wrapper form-buttons-auto   jsTest-button-wrapperField">
            <button id="input_2" type="submit" class="form-submit-button submit-button jf-form-buttons jsTest-submitField" data-component="button" data-content="">
              Submit
            </button>
           
          </div>
       
        </div>
            <iframe src="https://www.velgoodies.com/DDA Vett Form/Student_Device_Request_DDA_Review.html" style="width:100%; height:800px;"></iframe>
      </li>
      
      
    </ul>
    
 <div class = "searchBoxSection">
             <input class="searchBox"  type="text" id="myInput" onkeyup="searchBar()" placeholder="Search the Notes Column..." title="Search the Notes Column..">   
             
     <?php
  
  //Form Variables 
$tDate = $_POST['tDate'];
$DDAName = $_POST['q6_selectYour'];
$schoolName = $_POST['q8_selectYour8'];
$gradeLevel = $_POST['q9_selectThe9'];
$reason = $_POST['q7_reasonFor'];
$studentFirstName = $_POST['firstName'];
$studentLastName = $_POST['lastName'];
$psid = $_POST['q13_enterThe'];

//Database Connection

$db_host = 'localhost:3306';
$db_name = 'coxwm11_SDRForm';
$db_user = 'coxwm11_VEL';
$db_pw = 'Ethel1908!!!';

$conn = new mysqli($db_host, $db_user, $db_pw, $db_name );


if($conn-> connect_error){
    die('Connection Failed : '.$conn -> connect_error);
    
   
}else{
  
     $result = mysqli_query ($conn, "SELECT * FROM `Student Device Request` WHERE `School` = \"$schoolName\" AND `Addressed` = 'N' ORDER BY `psid` ");
     
      if((mysqli_num_rows($result) > 0)){
        
          
        
          //echo submission stuff for student
          
           echo "<table  id = 'myTable' width =100% border = 1px text-align=center>";
           
echo "<colgroup>";      
      echo "<col width =100px>";
echo "<col width =100px>";
echo "<col >";
echo "<col >";
echo "<col >";
echo "<col >";
echo "<col >";
echo "<col >";
echo "<col >";

echo "</colgroup>"; 

echo "<tr>"; 
echo "<th> Date </th>";
echo "<th> Device Ambassador </th>";
echo "<th> School </th>";
echo "<th> Student Grade </th>";
echo "<th> Reason for Request </th>";
echo "<th> Student Name</th>";
echo "<th> PSID </th>";
echo "<th> Notes </th>";
echo "<th> Checkbox </th>";
echo "</tr>";

while($row = $result->fetch_assoc()) {
    
echo "<tr >";
echo "<td  >" . $row['Date'] . "</td>";
echo "<td style=text-align:center; >" . $row['DDAName'] . "</td>";
echo "<td  >" . $row['School'] . "</td>";
echo "<td style=text-align:center; >" . $row['Grade'] . "</td>";
echo "<td  >" . $row['Reason'] . "</td>";
echo "<td  >" . $row['FirstName'] . " " . $row['LastName'] ."</td>";
echo "<td  id ='copytext' >" . $row['PSID'] . "</td> ";
echo "<td  >" . $row['Notes'] . "</td>";
echo "<td style=text-align:center;> <input type='checkbox' name='checkBox' </td>";

echo "</tr>";

    
}

  echo "</table>";
 

$result-> close();



          
      }
      
      else{


          
         echo"<h3> There are no submissions. </h3>";
  
   
    
 
    
          
      }
      
      
      
      
      
   
    
    $conn->close(); 
     
    
    
}
  
  
  ?> 
  </div>
  

  
  
  <script>
  JotForm.showJotFormPowered = "new_footer";
  </script>
  <script>
  JotForm.poweredByText = "Powered by Jotform";
  </script>
  <input type="hidden" class="simple_spc" id="simple_spc" name="simple_spc" value="221106862477053" />
  <script type="text/javascript">
  var all_spc = document.querySelectorAll("form[id='221106862477053'] .si" + "mple" + "_spc");
for (var i = 0; i < all_spc.length; i++)
{
  all_spc[i].value = "221106862477053-221106862477053";
}
  </script>
  <div class="formFooter-heightMask">
  </div>

</form>





</body>
</html>



<script type="text/javascript">JotForm.ownerView=true;</script><script src="https://cdn.jotfor.ms//js/vendor/smoothscroll.min.js?v=3.3.32846"></script>
<script src="https://cdn.jotfor.ms//js/errorNavigation.js?v=3.3.32846"></script>
